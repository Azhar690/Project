<!DOCTYPE html>
<html lang=en-US prefix="og: http://ogp.me/ns#" class=no-js>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />


<head>
   
    <link rel=stylesheet id=wp-block-library-css href='css/style.min4d2c.css?ver=5.2.4' type=text/css media=all>
    <link rel=stylesheet id=contact-form-7-css href='css/styles33a6.css?ver=4.9' type=text/css media=all>
    <link rel=stylesheet id=math-captcha-frontend-css href='css/frontend4d2c.css?ver=5.2.4' type=text/css media=all>
    <link rel=stylesheet id=megamenu-css href='css/style345d.css?ver=020915' type=text/css media=all>
    <link rel=stylesheet id=dashicons-css href='css/dashicons.min4d2c.css?ver=5.2.4' type=text/css media=all>
    <link rel=stylesheet id=twentyfifteen-fonts-css href='https://fonts.googleapis.com/css?family=Noto+Sans%3A400italic%2C700italic%2C400%2C700%7CNoto+Serif%3A400italic%2C700italic%2C400%2C700%7CInconsolata%3A400%2C700&amp;subset=latin%2Clatin-ext' type=text/css
        media=all>
    <link rel=stylesheet id=genericons-css href='genericons/genericonscf1b.css?ver=3.2' type=text/css media=all>
    <link rel=stylesheet id=twentyfifteen-style-css href='css/style4d2c.css?ver=5.2.4' type=text/css media=all>
    
   
    <link rel="shortcut icon" href=/solutiondots/favicon.png>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive-style.css">
    <link rel="stylesheet" type="text/css" href="css/slider.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/fonts.css">
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>
   <script type="text/javascript" src="recaptcha/api.js"></script>
   <!-- Bootstrap implementation -->
    <link href="dist/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css" />
    <!-- FONTELLO -->
    <link href="font/fontello/css/fontello.css" rel="stylesheet" type="text/css" />
    <link href="font/fontello/css/animation.css" rel="stylesheet" type="text/css" />
    <!--if IE 7
    link(rel='stylesheet', href='font/fontello/css/fontello-ie7.css')
    -->
    <!-- ANONYMOUS PRO FONT-->
    <link href="http://fonts.googleapis.com/css?family=Anonymous+Pro:400,700" rel="stylesheet" type="text/css" />
    <!-- DRIPICONS -->
    <link href="font/dripicons/webfont.css" rel="stylesheet" type="text/css" />
    <!-- SIMPLE LINE ICONS -->
    <link href="font/simple-line-icons/simple-line-icons.css" rel="stylesheet" type="text/css" />
    <!-- THEMIFY ICONS -->
    <link href="font/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
    <!-- FONTASTIC ICONS -->
    <link href="font/fontastic/styles.css" rel="stylesheet" type="text/css" />
    <!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
    <link href="css/extralayers.css" media="screen" rel="stylesheet" type="text/css" />
    <link href="rs-plugin/css/settings.css" media="screen" rel="stylesheet" type="text/css" />
    <!-- CarouFredSel -->
    <link href="css/caroufredsel.css" rel="stylesheet" type="text/css" />
    <!-- WOW.JS REVEAL ANIMATIONS -->
    <link href="css/animate.css" rel="stylesheet" type="text/css" />
    <!-- PYE CHART -->
    <link href="css/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" />
    <!-- Hover Effect Ideas -->
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,800,300' rel='stylesheet' type='text/css' />
    <link href="css/HoverEffectIdeas/css/demo.css" rel="stylesheet" type="text/css" />
    <link href="css/HoverEffectIdeas/css/set1.css" rel="stylesheet" type="text/css" />
    <!-- Lightcase ( image popup preview ) -->
    <link href="plugins/lightcase/css/lightcase.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   
   

<body class="page-template-default page page-id-61 mega-menu-my-custom-menu  hidenav removebullets">
   
<!-- start preloader -->
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<!-- end preloader -->
<!-- Navigation -->
<div class="navigation ">


        <div class="container">
            <div class="logo"><a href="index.html"><img src="images/logo.png" class="white mt5 relative z100" alt=""/></a></div>

            <div class="navbar navbar-default" role="navigation">
                <div class="container-fluid relative">

                    <button type="button" class="btn left hide-show-button none">
                        <span class="burgerbar"></span>
                        <span class="burgerbar"></span>
                        <span class="burgerbar"></span>
                    </button>
                    <a href="#" class="closemenu"></a> 

                    <!-- mobile version drop menu -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle hamburger" data-toggle="collapse" data-target=".navbar-collapse">
                          <span class="sr-only">Toggle navigation</span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                        </button>
                    </div>
                    
                    <!-- menu -->
                    <div class="mainmenu mobanim dark-menu navbar-collapse white collapse offset-0 ">
                        <ul class="nav navbar-nav mobpad">

                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Company</a>
                              <ul class="dropdown-menu">
                              
                                <li><a href="#">About</a></li>
                                <li><a href="#">History</a></li>
                                <li><a href="#">Vision</a></li>
                                <li><a href="#">Mission</a></li>
                                <li><a href="#">Quality Management</a></li>
                              </ul>
                            </li>
                            
                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Products</a>
                              <ul class="dropdown-menu">
                              

                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">AndroHealth Solutions</a>
                                    
                                </li>
                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">Almaali</a>
                                    
                                </li>
                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">BinQasem</a>
                                    
                                </li>
                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">Alamakin</a>
                                    
                                </li>

                                
        
                            
                                
                              </ul>
                            </li>           

                            <li class="dropdown">
                              <a class="dropdown-toggle" href="index.html">Industry</a>
                            <ul class="dropdown-menu">
                              
                                <li><a href="#">Health Care</a></li>
                                <li><a href="#">Hospitality</a></li>
                                
                              </ul>
                            </li>
                             
                            
                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Services <b class="caret"></b></a>
                             <ul class="dropdown-menu">
                              

                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">IT Services</a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Enterprise Softwere Development </a></li>
                                        <li><a href="#">Web Development</a></li>
                                        <li><a href="#">Custom Software Development</a></li>
                                        <li><a href="#">Web/Cloud Based Application</a></li>
                                        
                                    </ul>
                                </li>
                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">Support Services</a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Full Installation</a></li>
                                        <li><a href="#">Maintanence Support</a></li>
                                        
                                        
                                    </ul>   
                                </li>
                              
                                
                              </ul>
                            </li>
                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Portfolio <b class="caret"></b></a>
                              
                            </li>
                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Blogs <b class="caret"></b></a>
                            
                            </li>
                            <li><a href="contact.html">Contact</a></li>
                        </ul>
                    </div>
                
                    

                    <div class="dots">
                        <a href="#" class="opendots">
                            <span class="icon-dots"></span>
                            <span class="icon-dots"></span>
                            <span class="icon-dots"></span>
                        </a>
                    </div>          
                    
                </div>
            </div>      
            </div>
        </div>

<!-- End of Navigation -->          

<!-- START REVOLUTION SLIDER 3.1 rev5 fullwidth mode -->
<div id="parallax-off" class="tp-banner-container relative">
    <div class="tp-banner" >
        <ul>

            <!-- SLIDE 1  -->
            <li  data-transition="fade" data-slotamount="1" data-masterspeed="2000" data-thumb="images/slider/girls.jpg" data-delay="12000"  data-saveperformance="on"  data-title="Ken Burns Slide" data-color="white">
                <!-- MAIN IMAGE -->
                <img src="images/dummy.png" alt="" data-lazyload="images/Mainimage.jpg" data-bgposition="left center" data-kenburns="on" data-duration="12000" data-ease="Power0.easeInOut" data-bgfit="100" data-bgfitend="100" data-bgpositionend="center center">

                <!-- LAYER 1 -->
                <div class="prlx-on tp-caption slidertitle customin customout tp-resizeme"
                    data-x="center"  data-voffset="-50"
                    data-y="center"  data-hoffset="0"
                                            
                    data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                    data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                    data-speed="500"
                    data-start="3500"
                    data-easing="Power3.easeInOut"
                    data-splitin="chars"
                    data-splitout="chars"
                    data-elementdelay="0.05"
                    data-endelementdelay="0.05"
                    data-endspeed="300"
                    style="z-index: 10;"
                    >Make The Shift From Now to Next.

                </div>
                
                <!-- LAYER 2 -->
                <div class="prlx-on tp-caption slidersubtitle randomrotate customout tp-resizeme"
                    data-x="center"  data-voffset="0"       
                    data-y="center"  data-hoffset="0"   
                    
                    data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                    data-speed="500"
                    data-start="500"
                    data-easing="Power3.easeInOut"
                    data-splitin="chars"
                    data-splitout="chars"
                    data-elementdelay="0.05"
                    data-endelementdelay="0.05"                     
                    data-endspeed="100"
                    style="z-index: 10;"
                    >We merge imagination and technology to help brands grow in an age of digital transformation.

                </div>
                
                
                <!-- SCROLL -->
                <div class="prlx-off tp-caption caption-white-bold-caps customin customout"
                    data-x="center"   data-voffset="-20"
                    data-y="bottom"   data-hoffset="0"  
                                            
                    data-customin="opacity:0;"
                    data-customout="opacity:1;"
                    data-speed="500"
                    data-start="0"
                    data-easing="easeOut"  
                    style="z-index: 10;"
                    >
                    <div class=" rs-slideloop"          
                    data-easing="Power3.easeInOut"
                    data-speed="0.5"
                    data-ys="-5"
                    data-ye="5"
                    data-xs="0"
                    data-xe="0"
                    >
                    <span class="ti-mouse size30 cwhite"></span>
                    </div>
                </div>  

                <!-- Filter dark -->
                <div class="tp-caption customin customout"
                     data-x="center"
                     data-y="center"

                     data-customin="opacity:0;"
                     data-customout="opacity:1;"
                     data-speed="600"
                     data-start="0"
                     data-easing="easeOut"  
                     style="z-index: 4; display:block; background:rgba(0,0,0,0.5); width:100%; height:100%;"
                ></div>
            </li>

            <!-- VIDEO  -->
            <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-color="white">
            
                <!-- MAIN IMAGE -->
                <img src="http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.jpg"  alt="video_forest"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">
                <!-- LAYERS -->

                <!-- LAYER NR. 1 -->
                <div class="tp-caption tp-fade fadeout fullscreenvideo"
                    data-x="0"
                    data-y="0"
                    data-speed="1000"
                    data-start="0"
                    data-easing="Power4.easeOut"
                    data-endspeed="1500"
                    data-endeasing="Power4.easeIn"
                    data-autoplay="true"
                    data-autoplayonlyfirsttime="false"
                    data-nextslideatend="true"
                    data-forceCover="1"
                    data-aspectratio="16:9"
                    data-forcerewind="on"
                    style="z-index: 2">
                <!-- data-dottedoverlay="twoxtwo" -->

                <video class="video-js vjs-default-skin whfull" preload="none" poster='http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.jpg' >
                    <source src='http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.mp4' type='video/mp4' />
                    <source src='http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.webm' type='video/webm' />
                    <source src='http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.ogv' type='video/ogg' />
                </video>

                </div>

                <!-- Filter maron -->
                <div class="tp-caption "
                     data-x="center"
                     data-y="center"
                     data-speed="600"
                     data-start="0"
                     data-easing="easeOut"  
                     style="z-index: 4; display:block; background:rgba(102,102,51,0.1); width:100%; height:100%;"
                     ></div>

                <!-- Filter dark -->
                <div class="tp-caption customin customout"
                     data-x="center"
                     data-y="center"

                     data-customin="opacity:0;"
                     data-customout="opacity:1;"
                     data-speed="600"
                     data-start="0"
                     data-easing="easeOut"  
                     style="z-index: 4; display:block; background:rgba(0,0,0,0.5); width:100%; height:100%;"
                     ></div>

                <!-- SCROLL -->
                <div class="prlx-off tp-caption caption-white-bold-caps customin customout"
                    data-x="center"   data-voffset="-20"
                    data-y="bottom"   data-hoffset="0"  
                                            
                    data-customin="opacity:0;"
                    data-customout="opacity:1;"
                    data-speed="500"
                    data-start="0"
                    data-easing="easeOut"  
                    style="z-index: 10;"
                    >
                    <div class=" rs-slideloop"          
                    data-easing="Power3.easeInOut"
                    data-speed="0.5"
                    data-ys="-5"
                    data-ye="5"
                    data-xs="0"
                    data-xe="0"
                    >
                    <span class="ti-mouse size30 cwhite"></span>
                    </div>
                </div>  

                <!-- LAYER NR. 1 -->
                <div class="prlx-on tp-caption slidertitle customin customout"
                    data-x="center"
                    data-y="center"
                    data-captionhidden="on"


                    data-splitin="words"
                    data-elementdelay="0.25"
                    data-start="200"
                    data-speed="600"
                    data-easing="Back.easeOut"
                    data-customin="x:0;y:-20;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"



                    data-frames="{ typ :lines;
                                 elementdelay :0.1;
                                 start:1650;
                                 speed:500;
                                 ease:Power3.easeOut;
                                 animation:x:0;y:-20;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
                                 },
                                 { typ :lines;
                                 elementdelay :0.1;
                                 start:2150;
                                 speed:500;
                                 ease:Power3.easeOut;
                                 animation:x:0;y:-40;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
                                 }
                                 "

                    data-splitout="words"
                    data-endelementdelay="0.1"
                    data-customout="x:0;y:0;z:0;rotationX:40;rotationY:70;rotationZ:0;scaleX:0.85;scaleY:0.85;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                    data-endspeed="500"
                    data-endeasing="Power4.easeIn"

                    style="z-index: 4">Another Step towards a Better World 

                </div>

                <div class="prlx-on tp-caption slidersubtitle customin customout"
                    data-x="center"   data-hoffset="0"
                    data-y="center"   data-voffset="30"

                    data-splitin=""
                    data-elementdelay=""
                    data-start="1600"
                    data-speed="600"
                    data-easing="Power3.easeOut"
                    data-customin="x:0;y:30;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"

                    data-frames="{ typ :lines;
                                 elementdelay :0.1;
                                 start:2150;
                                 speed:500;
                                 ease:Power3.easeOut;
                                 animation:x:0;y:-35;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
                                 }
                                 "

                    data-splitout="lines"
                    data-endelementdelay="0.1"
                    data-customout="x:-230;y:-20;z:0;rotationX:0;rotationY:0;rotationZ:90;scaleX:0.2;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%"
                    data-endspeed="500"

                    data-endeasing="Back.easeIn"
                    data-captionhidden="on"
                    style="z-index: 10">Ideal confluence of expertise & innovations ..

                </div>

                
            </li>

        </ul>
        <div class="tp-bannertimer none"></div>
    </div>
</div>
<!-- END REVOLUTION SLIDER -->

   
  
    <div class="welcome-section bg-white">
        <div class=container>
            <div class="row margin-btm-3x">
                <div class="col-md-7 col-sm-7 col-xs-12">
                    <div class="hr margin-btm-1x school_text"><h2>Alamakin:</h2></div>
                    <div class=hr>
                        <p>From that first airbed, Alamakin.com grew from person to person, block by block, city by city. Today, our community is in 34,000 cities in 192 countries. This idea is about much more than just making ends meet. At Alamakin.com, we are creating a door to an open world—where everyone's at home and can belong, anywhere.
In Saudi Arabia, our 15,000 hosts are regular people from all five boroughs. Eighty-seven percent of them rent the homes in which they live. On average, they are at the median income level and more than half of them depend on Alamakin.com to help them stay in their home. From Harlem to Greenpoint, Staten Island to Nolita, 87 percent of our hosts live outside of the midtown-Manhattan hotel district. They are teachers, artists, students, and retirees who love doing this.

</p>
                        <p>Alamakin features are:</p>
                    </div>
                    <div class=hr>
                        <div class=school-services>
                            <ul>
                                <li>Rental halls</li>
                                <li>Istirahas</li>
                                <li>Apartments</li>
                                <li>Hotels</li>
                                <li>Chalets</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 col-sm-5 col-xs-12">
                    <div class=take-testdrive>
                        <div class=hr>
                            <h5>Take a test drive</h5>
                        </div>
                        <div role=form class=wpcf7 id=wpcf7-f346-o1 lang=en-US dir=ltr>
                            <div class=screen-reader-response></div>
                            <form action=https://solutiondots.com/school-management-system/#wpcf7-f346-o1 method=post class=wpcf7-form novalidate=novalidate>
                                <div style="display: none;">
                                    <input type=hidden name=_wpcf7 value=346>
                                    <input type=hidden name=_wpcf7_version value=4.9>
                                    <input type=hidden name=_wpcf7_locale value=en_US>
                                    <input type=hidden name=_wpcf7_unit_tag value=wpcf7-f346-o1>
                                    <input type=hidden name=_wpcf7_container_post value=0></div>
                                <div class="wpcf7-response-output wpcf7-display-none"></div>
                                <p><span class="wpcf7-form-control-wrap your-email"><input
type=email name=your-email value size=40 class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-control" id=test_email aria-required=true aria-invalid=false placeholder=Email...></span> </label><br>
                                    <input type=submit value=Submit class="wpcf7-form-control wpcf7-submit btn pull-right" id=test_submit></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class=row>
                <div class=managing-tree>
                    <div class="col-md-7 col-sm-6 col-xs-8">
                         <h3 class="align-left">Alamakin From that first airbed, Alamakin.com grew from person to person, block by block, city by city.</h3>
                         <br>
                         <p>Alamakin Management System Modules are as listed below</p>

                    </div>

                    <div class="col-md-5 col-sm-6 col-xs-4"><img src=images/4.png title="Solution Dots" alt="School attendance software" width=100%></div>
                </div>
            </div>
            <div class=advence-features style="margin-top: 30px;">
                <div class="col-md-4 col-xs-12">
                    <ul>
                        <li>Appointment Management (Online & Offline)</li>
                        <li>OutPatient Management</li>
                        <li>Integrated Pharmacy</li>
                        <li>Integrated Labs</li>
                        <li>Integrated Radiology Management</li>
                        <li>Human Resource Management</li>
                        <li>Payroll Management </li>
                    </ul>
                </div>
                <div class="col-md-4 col-xs-12">
                    <ul>
                        <li>Inventory Management System</li>
                        <li>Emergency Department Management</li>
                        <li>Patients Dietary Management</li>
                        <li>Laundry Management</li>
                        <li>Financial Accounting Management</li>
                        <li>Doctor Module</li>
                        <li>Nurse Management System</li>
                </div>
                <div class="col-md-4 col-xs-12">
                    <ul>
                        <li>Cash Management System</li>
                        <li>Fixed Assets Management System</li>
                        <li>Claims Management System</li>
                        <li>Blood Bank Management System</li>
                        <li>Wards Management System</li>
                        <li>Wards Management System</li>
                        <li>Operation theater Management System</li>
                       
                    </ul>
                </div>
            </div>
            <div class=row>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class=hr>
                        <div class=" responsive-img text-center"><img src=images/ak1.png alt="School software" title=Solutiodots></div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class=hr>
                        <div class=" responsive-img text-center"><img src=images/ak2.png alt="School administration software" title=Solutiodots></div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class=hr>
                        <div class=" responsive-img text-center"><img src=images/ak3.jpg alt="education ERP" title=Solutiodots></div>
                    </div>
                </div>
            </div>
            <div class=row>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <h4>Advantages of Hospital Management System:</h4>
                    <p>The implementation of Andro hospital management system project provides the institution with different advantages that improve the service quality and efficiency. As mentioned above it is created for three groups of users: patients, hospital staff and management, and third-parties like drug suppliers and insurance companies. The interaction between them conveys the general performance. The benefits received by a certain group of users also positively influence the work of the others. Cooperation and communication are the fundamental requirements here.In order to create the hospital management system feature list, you need to identify your priorities by choosing the benefits that are prior for your case.</p>
                    <h4>Improved Processes:</h4>
                    <p>Automation is one of the main benefits here. It helps to optimize the user experience. Medical specialists, patients, and hospital authorities can interact online, make the appointments and exchange information.</p>
                    <h4>Digital medical records:</h4>
                    <p>The hospital database includes all the necessary patient data. The disease history, test results, prescribed treatment can be accessed by doctors without much delay in order to make an accurate diagnosis and monitor the patient’s health. It enables lower risks of mistakes.</p>
                    <h4>Staff interaction:</h4>
                    <p>It is vital to engage all of your employees for improved coordination and teamwork. They do not need to make special requests and wait for a long time for an answer. Each specialist will be in charge of certain process stage and can share outcomes with colleagues just in one click.</p>
                    <h4>Facility management:</h4>
                    <p>Hospitals authorities are able to manage their available resources, analyze staff work, reduce equipment downtime, optimize the supply chain, etc. Another fact to mention is that hospital staff deal with the digital data instead of endless paperwork.</p>
                    <h4>Financial control and tax planning</h4>
                    <p>The management has the ability to monitor different financial operations including expenses, profits, and losses, paying bills and taxes, in and outpatient billing. The financial awareness helps to analyze business prospects quite clear and move in the right direction.</p>
                    <h4>Market strategy:</h4>
                    <p>Due to the high market competitive nature, the medical industry is also open to all the different innovations that enable communication between patients, doctors, suppliers, and marketing services providers.</p>
                    <h4>Insurance claims processing:</h4>
                    <p>Integration with health insurance services improves the experience of the patients and brings benefits to the institution. It allows you to be innovative and helps both the patient and hospital to handle many aspects of the insurance process successfully.</p>
                    <h4>Less time consuming:</h4>
                    <p>As the services and interactions are improved in all possible ways, everything is being planned with greater precision. It saves the time of all the system users and provides them with up-to-date information.</p>
                   
                </div>
            </div>
            <div class=row>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class=infrastructure>
                        <div class="col-md-9 col-sm-9 col-xs-12">
                            <div class=hr>
                                <h4>Most Trusted Cloud Infrastructure</h4>
                            </div>
                            <h6>CloudSuite of SolutionDot has combined the industrial expertise that distinguished user’s experience with world’s most trusted infrastructure from Amazon Web Services. Now grow your business by getting the advantage of Amazon’s
                                expertise.</h6>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12">
                            <div class=pull-right><img class="pull-right margin-1x margin-top-50" src=images/amazon-logo.png title="Solution Dots" alt=amazon-logo></div>
                        </div>
                        <div class=clearfix></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .partner-logo {
            margin: 15px 0px;
        }

        .partner-logo ul li {
            list-style: none;
            display: inline;
            float: left;
            width: 16%;
            margin: 0px 4% 0px 0%;
        }

        .partner-logo p {
            color: #333;
            font-size: 1em;
            text-align: left;
        }

        .country-change {
            position: absolute;
            right: 0;
            bottom: -276px;
        }

        .country-links {
            color: #007ac9;
        }
    </style>
    <div class=partner-logo>
        <div class=container>
            <p>Partners</p>
            <ul>
                <li><img src=images/partner-logos/ibm.png class=img-responsive></li>
                <li><img src=images/partner-logos/google.png class=img-responsive></li>
                <li><img src=images/partner-logos/amazon.png class=img-responsive></li>
                <li><img src=images/partner-logos/honeywell.png class=img-responsive></li>
                <li><img src=images/partner-logos/sap.png class=img-responsive></li>
            </ul>
        </div>
    </div>
  
    <?php include("footer.php"); ?>
 <!-- jQuery --> 
<script type="text/javascript" src="js/jquery.js"></script>
<!-- COMPRESSED -->
<script type="text/javascript" src="js/compressed.js"></script>
<!-- Parallax & Animations -->
<script type="text/javascript" src="js/animations.js"></script>
<!-- FUNCTIONS -->
<script type="text/javascript" src="js/functions.js"></script>
<!-- Including all compiled Bootstrap plugins  --> 
<script type="text/javascript" src="dist/js/bootstrap.min.js"></script>
 
</body>


</html>