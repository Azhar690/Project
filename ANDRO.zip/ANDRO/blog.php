
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<title>Androomeda</title>
	<!-- Bootstrap implementation -->
	<link href="dist/css/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<!-- GOOGLE FONTS -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css" />
	<!-- FONTELLO -->
	<link href="font/fontello/css/fontello.css" rel="stylesheet" type="text/css" />
	<link href="font/fontello/css/animation.css" rel="stylesheet" type="text/css" />
	<!--if IE 7
	link(rel='stylesheet', href='font/fontello/css/fontello-ie7.css')
	-->
	<!-- ANONYMOUS PRO FONT-->
	<link href="http://fonts.googleapis.com/css?family=Anonymous+Pro:400,700" rel="stylesheet" type="text/css" />
	<!-- DRIPICONS -->
	<link href="font/dripicons/webfont.css" rel="stylesheet" type="text/css" />
	<!-- SIMPLE LINE ICONS -->
	<link href="font/simple-line-icons/simple-line-icons.css" rel="stylesheet" type="text/css" />
	<!-- THEMIFY ICONS -->
	<link href="font/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
	<!-- FONTASTIC ICONS -->
	<link href="font/fontastic/styles.css" rel="stylesheet" type="text/css" />
	<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
	<link href="css/extralayers.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="rs-plugin/css/settings.css" media="screen" rel="stylesheet" type="text/css" />
	<!-- CarouFredSel -->
	<link href="css/caroufredsel.css" rel="stylesheet" type="text/css" />
	<!-- WOW.JS REVEAL ANIMATIONS -->
	<link href="css/animate.css" rel="stylesheet" type="text/css" />
	<!-- PYE CHART -->
	<link href="css/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" />
	<!-- Hover Effect Ideas -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,800,300' rel='stylesheet' type='text/css' />
	<link href="css/HoverEffectIdeas/css/demo.css" rel="stylesheet" type="text/css" />
	<link href="css/HoverEffectIdeas/css/set1.css" rel="stylesheet" type="text/css" />
	<!-- Lightcase ( image popup preview ) -->
	<link href="plugins/lightcase/css/lightcase.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>
<body class="hidenav removebullets">

<!-- start preloader -->
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<!-- end preloader -->
<?php include("header.php"); ?>
<!-- END REVOLUTION SLIDER -->

<div class="bgwhite borderbottom space20 relative z20"></div>

<div class="bgxlight borderbottom relative z20">
	<div class="container ptb40 cdark">
		<h3 class="text-center titlefont size30 c999">Blog</h3>
		<div class="pt10 breadcrumbs">
			<a href="#"><span class="ti-home"></span></a> <i>/</i>
			<a href="#">Blog</a>
		</div>
		<!-- <div class="toparrow"></div> -->
	</div>
</div>

<div class="container pt60">
	
	<div id="sidecontent" class="col-md-9 offset-0 pr40 mb50">
	<!-- CONTENT -->

		<!-- post -->
		<div class="col-md-12">
			<div class="relative">
				<img src="images/blog2.jpg" class="fwi" alt=""/>
				<div class="blogdate">
					<p class="fontproxima size30 caps nospace lh30">25</p>
					<p class="fontproxima size12 caps nospace">may</p>
				</div>
			</div>
			<div class="col-md-12 bgwhite pt30 pb20 plr50">
				<div class="col-md-4 size12 titlefont mt20">
					<span class="fontproximabold size12 caps">Posted by</span>
					<p>Avision Staff</p>
					<span class="fontproximabold size12 caps">Category</span>
					<p class="nospace"><span class="ti-check cmaincolor mr5"></span>Graphic Design</p>
					<p class="nospace"><span class="ti-check cmaincolor mr5"></span>Freebies</p>
				</div>
				<div class="col-md-8 mt20">
					<p class="fontproximabold size20">What are the benefits of using a CCTV system in 2019?</p>
					<span class="c666 lh24">
						 CCTV (closed-circuit television) system allows the use of video cameras to monitor the interior and exterior of a property, transmitting the signal to a monitor or set of monitors.
					</span>
				</div>
				<div class="clearfix"></div>
				<a class="btn btnwhite btn-default mt20 mb10 pull-right" href="blog-1.php"><i class="icon-article-alt"></i> Read more</a>
				<div class="clearfix"></div>
			</div>
		</div>

		<!-- post -->
		<div class="col-md-12 mt50">
			<div class="relative">
				<img src="images/blog1.jpg" class="fwi" alt=""/>
				<div class="blogdate">
					<p class="fontproxima size30 caps nospace lh30">13</p>
					<p class="fontproxima size12 caps nospace">May</p>
				</div>
			</div>
			<div class="col-md-12 bgwhite pt30 pb20 plr50">
				<div class="col-md-4 size12 titlefont mt20">
					<span class="fontproximabold size12 caps">Posted by</span>
					<p>Avision Staff</p>
					<span class="fontproximabold size12 caps">Category</span>
					<p class="nospace"><span class="ti-check cmaincolor mr5"></span>Graphic Design</p>
				</div>
				<div class="col-md-8 mt20">
					<p class="fontproximabold size20">6 Reasons why <a href=“http://androhealthsolutions.com”>HIS</a> is a necessary change you need in your hospital</p>
					<span class="c666 lh24">
						Here's a bunch of numbers. They may look random but they're my phone number. I'm no hero.
						Climb leg rub face on everything give attitude nap all day for under the bed. 
						Chase mice attack feet but rub face on everything hopped up on goofballs.
						Efficiently unleash cross-media information without cross-media value. 
					</span>
				</div>
				<div class="clearfix"></div>
				<a class="btn btnwhite btn-default mt20 mb10 pull-right" href="blog-2.php"><i class="icon-article-alt"></i> Read more</a>
				<div class="clearfix"></div>
			</div>
		</div>

		<div class="clearfix"></div>
		<div class="divider bglight3 mtb50"></div>

		<nav class="pull-right mr10">
		  <ul class="pagination2">
		    <li>
		      <a href="#" aria-label="Previous">
		        <span class="ti-arrow-left ml-2"></span>
		      </a>
		    </li>
		    <li class="active"><a href="#">1</a></li>
		    <li><a href="#">2</a></li>
		    <li><a href="#">3</a></li>
		    <li><a href="#">4</a></li>
		    <li><a href="#">5</a></li>
		    <li>
		      <a href="#" aria-label="Next">
		        <span class="ti-arrow-right ml-2"></span>
		      </a>
		    </li>
		  </ul>
		</nav>

	<!-- END CONTENT -->
	</div>
	<div class="col-md-3 offset-0">
		<div id="make-this-fixed-off" class="rightmenu ">
			<ul>
				<li class="title">Categories</li>
				<li><a href="#">Company<span></span></a></li>
				<li><a href="#">Products<span></span></a></li>
				<li><a href="#">Industory<span></span></a></li>
				<li><a href="#">Services<span></span></a></li>
				<li><a href="#">Portfolio<span></span></a></li>
				<li><a href="#">Blogs<span></span></a></li>
				<li><a href="#">AbouUs<span></span></a></li>
				<li><a href="#">Contact<span></span></a></li>
				
			</ul>
			
			<!-- Tabs -->
			<div class="bs-example-tabs mt30">
			    <ul role="tablist" class="nav nav-tabs fb-tabs2" id="myTab2">
			      <li class="active caps fontproximabold"><a data-toggle="tab" role="tab" href="#tab-b">Popular</a></li>
			      <li class="caps fontproximabold"><a data-toggle="tab" role="tab" href="#tab2-b">Latest</a></li>
			    </ul>
			    <div class="tab-content " id="myTabContent2">
			      <div id="tab-b" class="tab-pane fade active in">
			        <div class="mt20">
			        	<div class="sidethumb">
			        		<a href="#"><img src="images/blog2.jpg" class="fwi" alt=""></a>
			        	</div>
			        	<a href="#">What are the benefits of using a CCTV system in 2019?</a>
			        	<p>18 comments</p>
			        	<div class="clearfix mtb10"></div>

			        	<div class="sidethumb">
			        		<a href="#"><img src="images/blog1.jpg" class="fwi" alt=""></a>
			        	</div>
			        	<a href="#">What are the bene6 Reasons why</a>
			        	<p>9 comments</p>
			        	<div class="clearfix mtb10"></div>

			        </div>
			      </div>
			     
			    </div>
			</div>
			<div class="clearfix"></div>

			<!-- Tags -->

			<div class="tags mt50">
				<h1 class="active caps fontproximabold size14">Tags</h1>
				<div class="divider bglight3 mtb10"></div>
				<span>Company</span>
				<span>Products</span>
				<span>Industory</span>
				<span>Services</span>
				<span>Portfolio</span>
				<span>Blogs</span>
				<span>Retina</span>
				<span>AboutUs</span>
				<span>Contact</span>
				
			</div>


		</div>
	</div>
</div>

<?php include("footer.php"); ?>
<p id="back-top"><a href="#top"><span class="ti-angle-up"></span></a></p>

<div class="newsletter-ani">
	<div class="circle-obj"></div>
	<div class="circle-obj2"><span class="ti-check"></span></div>
	<div class="circle-obj3 opensans xslim">Subscribed</div>
</div>

<!-- jQuery --> 
<script type="text/javascript" src="js/jquery.js"></script>
<!-- COMPRESSED -->
<script type="text/javascript" src="js/compressed.js"></script>
<!-- Parallax & Animations -->
<script type="text/javascript" src="js/animations.js"></script>
<!-- FUNCTIONS -->
<script type="text/javascript" src="js/functions.js"></script>
<!-- Including all compiled Bootstrap plugins  --> 
<script type="text/javascript" src="dist/js/bootstrap.min.js"></script>

</body>
</html>