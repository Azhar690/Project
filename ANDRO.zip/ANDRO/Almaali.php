<!DOCTYPE html>
<html lang=en-US prefix="og: http://ogp.me/ns#" class=no-js>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />


<head>
   
    <link rel=stylesheet id=wp-block-library-css href='css/style.min4d2c.css?ver=5.2.4' type=text/css media=all>
    <link rel=stylesheet id=contact-form-7-css href='css/styles33a6.css?ver=4.9' type=text/css media=all>
    <link rel=stylesheet id=math-captcha-frontend-css href='css/frontend4d2c.css?ver=5.2.4' type=text/css media=all>
    <link rel=stylesheet id=megamenu-css href='css/style345d.css?ver=020915' type=text/css media=all>
    <link rel=stylesheet id=dashicons-css href='css/dashicons.min4d2c.css?ver=5.2.4' type=text/css media=all>
    <link rel=stylesheet id=twentyfifteen-fonts-css href='https://fonts.googleapis.com/css?family=Noto+Sans%3A400italic%2C700italic%2C400%2C700%7CNoto+Serif%3A400italic%2C700italic%2C400%2C700%7CInconsolata%3A400%2C700&amp;subset=latin%2Clatin-ext' type=text/css
        media=all>
    <link rel=stylesheet id=genericons-css href='genericons/genericonscf1b.css?ver=3.2' type=text/css media=all>
    <link rel=stylesheet id=twentyfifteen-style-css href='css/style4d2c.css?ver=5.2.4' type=text/css media=all>
    
   
    <link rel="shortcut icon" href=/solutiondots/favicon.png>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/ie10-viewport-bug-workaround.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive-style.css">
    <link rel="stylesheet" type="text/css" href="css/slider.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/fonts.css">
    <script type="text/javascript" src="js/ie-emulation-modes-warning.js"></script>
   <script type="text/javascript" src="recaptcha/api.js"></script>
   <!-- Bootstrap implementation -->
    <link href="dist/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css" />
    <!-- FONTELLO -->
    <link href="font/fontello/css/fontello.css" rel="stylesheet" type="text/css" />
    <link href="font/fontello/css/animation.css" rel="stylesheet" type="text/css" />
    <!--if IE 7
    link(rel='stylesheet', href='font/fontello/css/fontello-ie7.css')
    -->
    <!-- ANONYMOUS PRO FONT-->
    <link href="http://fonts.googleapis.com/css?family=Anonymous+Pro:400,700" rel="stylesheet" type="text/css" />
    <!-- DRIPICONS -->
    <link href="font/dripicons/webfont.css" rel="stylesheet" type="text/css" />
    <!-- SIMPLE LINE ICONS -->
    <link href="font/simple-line-icons/simple-line-icons.css" rel="stylesheet" type="text/css" />
    <!-- THEMIFY ICONS -->
    <link href="font/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
    <!-- FONTASTIC ICONS -->
    <link href="font/fontastic/styles.css" rel="stylesheet" type="text/css" />
    <!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
    <link href="css/extralayers.css" media="screen" rel="stylesheet" type="text/css" />
    <link href="rs-plugin/css/settings.css" media="screen" rel="stylesheet" type="text/css" />
    <!-- CarouFredSel -->
    <link href="css/caroufredsel.css" rel="stylesheet" type="text/css" />
    <!-- WOW.JS REVEAL ANIMATIONS -->
    <link href="css/animate.css" rel="stylesheet" type="text/css" />
    <!-- PYE CHART -->
    <link href="css/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" />
    <!-- Hover Effect Ideas -->
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,800,300' rel='stylesheet' type='text/css' />
    <link href="css/HoverEffectIdeas/css/demo.css" rel="stylesheet" type="text/css" />
    <link href="css/HoverEffectIdeas/css/set1.css" rel="stylesheet" type="text/css" />
    <!-- Lightcase ( image popup preview ) -->
    <link href="plugins/lightcase/css/lightcase.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   
   

<body class="page-template-default page page-id-61 mega-menu-my-custom-menu hidenav removebullets">

<!-- start preloader -->
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<!-- end preloader -->
<!-- Navigation -->
<div class="navigation ">


        <div class="container">
            <div class="logo"><a href="index.html"><img src="images/logo.png" class="white mt5 relative z100" alt=""/></a></div>

            <div class="navbar navbar-default" role="navigation">
                <div class="container-fluid relative">

                    <button type="button" class="btn left hide-show-button none">
                        <span class="burgerbar"></span>
                        <span class="burgerbar"></span>
                        <span class="burgerbar"></span>
                    </button>
                    <a href="#" class="closemenu"></a> 

                    <!-- mobile version drop menu -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle hamburger" data-toggle="collapse" data-target=".navbar-collapse">
                          <span class="sr-only">Toggle navigation</span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                          <span class="icon-bar"></span>
                        </button>
                    </div>
                    
                    <!-- menu -->
                    <div class="mainmenu mobanim dark-menu navbar-collapse white collapse offset-0 ">
                        <ul class="nav navbar-nav mobpad">

                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Company</a>
                              <ul class="dropdown-menu">
                              
                                <li><a href="#">About</a></li>
                                <li><a href="#">History</a></li>
                                <li><a href="#">Vision</a></li>
                                <li><a href="#">Mission</a></li>
                                <li><a href="#">Quality Management</a></li>
                              </ul>
                            </li>
                            
                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Products</a>
                              <ul class="dropdown-menu">
                              

                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">AndroHealth Solutions</a>
                                    
                                </li>
                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">Almaali</a>
                                    
                                </li>
                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">BinQasem</a>
                                    
                                </li>
                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">Alamakin</a>
                                    
                                </li>

                                
        
                            
                                
                              </ul>
                            </li>           

                            <li class="dropdown">
                              <a class="dropdown-toggle" href="index.html">Industry</a>
                            <ul class="dropdown-menu">
                              
                                <li><a href="#">Health Care</a></li>
                                <li><a href="#">Hospitality</a></li>
                                
                              </ul>
                            </li>
                             
                            
                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Services <b class="caret"></b></a>
                             <ul class="dropdown-menu">
                              

                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">IT Services</a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Enterprise Softwere Development </a></li>
                                        <li><a href="#">Web Development</a></li>
                                        <li><a href="#">Custom Software Development</a></li>
                                        <li><a href="#">Web/Cloud Based Application</a></li>
                                        
                                    </ul>
                                </li>
                                <li class="dropdown relative">
                                    <a class="dropdown-toggle" href="#">Support Services</a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Full Installation</a></li>
                                        <li><a href="#">Maintanence Support</a></li>
                                        
                                        
                                    </ul>   
                                </li>
                              
                                
                              </ul>
                            </li>
                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Portfolio <b class="caret"></b></a>
                              
                            </li>
                            <li class="dropdown">
                              <a class="dropdown-toggle" href="#">Blogs <b class="caret"></b></a>
                            
                            </li>
                            <li><a href="contact.html">Contact</a></li>
                        </ul>
                    </div>
                
                    

                    <div class="dots">
                        <a href="#" class="opendots">
                            <span class="icon-dots"></span>
                            <span class="icon-dots"></span>
                            <span class="icon-dots"></span>
                        </a>
                    </div>          
                    
                </div>
            </div>      
            </div>
        </div>

<!-- End of Navigation -->          

<!-- START REVOLUTION SLIDER 3.1 rev5 fullwidth mode -->
<div id="parallax-off" class="tp-banner-container relative">
    <div class="tp-banner" >
        <ul>

            <!-- SLIDE 1  -->
            <li  data-transition="fade" data-slotamount="1" data-masterspeed="2000" data-thumb="images/slider/girls.jpg" data-delay="12000"  data-saveperformance="on"  data-title="Ken Burns Slide" data-color="white">
                <!-- MAIN IMAGE -->
                <img src="images/dummy.png" alt="" data-lazyload="images/Mainimage.jpg" data-bgposition="left center" data-kenburns="on" data-duration="12000" data-ease="Power0.easeInOut" data-bgfit="100" data-bgfitend="100" data-bgpositionend="center center">

                <!-- LAYER 1 -->
                <div class="prlx-on tp-caption slidertitle customin customout tp-resizeme"
                    data-x="center"  data-voffset="-50"
                    data-y="center"  data-hoffset="0"
                                            
                    data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                    data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                    data-speed="500"
                    data-start="3500"
                    data-easing="Power3.easeInOut"
                    data-splitin="chars"
                    data-splitout="chars"
                    data-elementdelay="0.05"
                    data-endelementdelay="0.05"
                    data-endspeed="300"
                    style="z-index: 10;"
                    >Make The Shift From Now to Next.

                </div>
                
                <!-- LAYER 2 -->
                <div class="prlx-on tp-caption slidersubtitle randomrotate customout tp-resizeme"
                    data-x="center"  data-voffset="0"       
                    data-y="center"  data-hoffset="0"   
                    
                    data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                    data-speed="500"
                    data-start="500"
                    data-easing="Power3.easeInOut"
                    data-splitin="chars"
                    data-splitout="chars"
                    data-elementdelay="0.05"
                    data-endelementdelay="0.05"                     
                    data-endspeed="100"
                    style="z-index: 10;"
                    >We merge imagination and technology to help brands grow in an age of digital transformation.

                </div>
                
                
                <!-- SCROLL -->
                <div class="prlx-off tp-caption caption-white-bold-caps customin customout"
                    data-x="center"   data-voffset="-20"
                    data-y="bottom"   data-hoffset="0"  
                                            
                    data-customin="opacity:0;"
                    data-customout="opacity:1;"
                    data-speed="500"
                    data-start="0"
                    data-easing="easeOut"  
                    style="z-index: 10;"
                    >
                    <div class=" rs-slideloop"          
                    data-easing="Power3.easeInOut"
                    data-speed="0.5"
                    data-ys="-5"
                    data-ye="5"
                    data-xs="0"
                    data-xe="0"
                    >
                    <span class="ti-mouse size30 cwhite"></span>
                    </div>
                </div>  

                <!-- Filter dark -->
                <div class="tp-caption customin customout"
                     data-x="center"
                     data-y="center"

                     data-customin="opacity:0;"
                     data-customout="opacity:1;"
                     data-speed="600"
                     data-start="0"
                     data-easing="easeOut"  
                     style="z-index: 4; display:block; background:rgba(0,0,0,0.5); width:100%; height:100%;"
                ></div>
            </li>

            <!-- VIDEO  -->
            <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-color="white">
            
                <!-- MAIN IMAGE -->
                <img src="http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.jpg"  alt="video_forest"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">
                <!-- LAYERS -->

                <!-- LAYER NR. 1 -->
                <div class="tp-caption tp-fade fadeout fullscreenvideo"
                    data-x="0"
                    data-y="0"
                    data-speed="1000"
                    data-start="0"
                    data-easing="Power4.easeOut"
                    data-endspeed="1500"
                    data-endeasing="Power4.easeIn"
                    data-autoplay="true"
                    data-autoplayonlyfirsttime="false"
                    data-nextslideatend="true"
                    data-forceCover="1"
                    data-aspectratio="16:9"
                    data-forcerewind="on"
                    style="z-index: 2">
                <!-- data-dottedoverlay="twoxtwo" -->

                <video class="video-js vjs-default-skin whfull" preload="none" poster='http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.jpg' >
                    <source src='http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.mp4' type='video/mp4' />
                    <source src='http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.webm' type='video/webm' />
                    <source src='http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.ogv' type='video/ogg' />
                </video>

                </div>

                <!-- Filter maron -->
                <div class="tp-caption "
                     data-x="center"
                     data-y="center"
                     data-speed="600"
                     data-start="0"
                     data-easing="easeOut"  
                     style="z-index: 4; display:block; background:rgba(102,102,51,0.1); width:100%; height:100%;"
                     ></div>

                <!-- Filter dark -->
                <div class="tp-caption customin customout"
                     data-x="center"
                     data-y="center"

                     data-customin="opacity:0;"
                     data-customout="opacity:1;"
                     data-speed="600"
                     data-start="0"
                     data-easing="easeOut"  
                     style="z-index: 4; display:block; background:rgba(0,0,0,0.5); width:100%; height:100%;"
                     ></div>

                <!-- SCROLL -->
                <div class="prlx-off tp-caption caption-white-bold-caps customin customout"
                    data-x="center"   data-voffset="-20"
                    data-y="bottom"   data-hoffset="0"  
                                            
                    data-customin="opacity:0;"
                    data-customout="opacity:1;"
                    data-speed="500"
                    data-start="0"
                    data-easing="easeOut"  
                    style="z-index: 10;"
                    >
                    <div class=" rs-slideloop"          
                    data-easing="Power3.easeInOut"
                    data-speed="0.5"
                    data-ys="-5"
                    data-ye="5"
                    data-xs="0"
                    data-xe="0"
                    >
                    <span class="ti-mouse size30 cwhite"></span>
                    </div>
                </div>  

                <!-- LAYER NR. 1 -->
                <div class="prlx-on tp-caption slidertitle customin customout"
                    data-x="center"
                    data-y="center"
                    data-captionhidden="on"


                    data-splitin="words"
                    data-elementdelay="0.25"
                    data-start="200"
                    data-speed="600"
                    data-easing="Back.easeOut"
                    data-customin="x:0;y:-20;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"



                    data-frames="{ typ :lines;
                                 elementdelay :0.1;
                                 start:1650;
                                 speed:500;
                                 ease:Power3.easeOut;
                                 animation:x:0;y:-20;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
                                 },
                                 { typ :lines;
                                 elementdelay :0.1;
                                 start:2150;
                                 speed:500;
                                 ease:Power3.easeOut;
                                 animation:x:0;y:-40;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
                                 }
                                 "

                    data-splitout="words"
                    data-endelementdelay="0.1"
                    data-customout="x:0;y:0;z:0;rotationX:40;rotationY:70;rotationZ:0;scaleX:0.85;scaleY:0.85;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                    data-endspeed="500"
                    data-endeasing="Power4.easeIn"

                    style="z-index: 4">Another Step towards a Better World 

                </div>

                <div class="prlx-on tp-caption slidersubtitle customin customout"
                    data-x="center"   data-hoffset="0"
                    data-y="center"   data-voffset="30"

                    data-splitin=""
                    data-elementdelay=""
                    data-start="1600"
                    data-speed="600"
                    data-easing="Power3.easeOut"
                    data-customin="x:0;y:30;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"

                    data-frames="{ typ :lines;
                                 elementdelay :0.1;
                                 start:2150;
                                 speed:500;
                                 ease:Power3.easeOut;
                                 animation:x:0;y:-35;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
                                 }
                                 "

                    data-splitout="lines"
                    data-endelementdelay="0.1"
                    data-customout="x:-230;y:-20;z:0;rotationX:0;rotationY:0;rotationZ:90;scaleX:0.2;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%"
                    data-endspeed="500"

                    data-endeasing="Back.easeIn"
                    data-captionhidden="on"
                    style="z-index: 10">Ideal confluence of expertise & innovations ..

                </div>

                
            </li>

        </ul>
        <div class="tp-bannertimer none"></div>
    </div>
</div>
<!-- END REVOLUTION SLIDER -->

    <div class="welcome-section bg-white">
        <div class=container>
            <div class="row margin-btm-3x">
                <div class="col-md-7 col-sm-7 col-xs-12">
                    <div class="hr margin-btm-1x school_text"><h2>Almaali School Management System</h2></div>
                    <div class=hr>
                        <p>Almaali Education Management is a web and mobile application developed specially to handle all the day to day functionalities of School / College and Universities. It is a Cloud Based School ERP Solution which will give most updated mobile application form to the Teachers, Students and Parents to help them in using the login from any place and any time.</p>
                        <p>Almali School ERP has different modules to manage and handle for example; Fees Management, Timetable, Attendance, Examinations, News, Hostel, Library, Transportation, School Calendar, Events etc. Additionally it has recently launched the new version with full fledged Human Resource module to manage the payroll of employees and their salary pay slips. The Finance module helps you to plan and assign fee structures for students. Genius School ERP System is also an excellent collaboration tool using its Task Priority feature. Also there is an internal messaging system within Genius which will help the Students, Teacher and Parents to communicate with each other.</p>
                    </div>
                    <div class=hr>
                        <div class=school-services>
                            <ul>
                                <li>Schools</li>
                                <li>Group of Institutions</li>
                                <li>Colleges</li>
                                <li>Training Centres</li>
                                <li>Universities</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 col-sm-5 col-xs-12">
                    <div class=take-testdrive>
                        <div class=hr>
                            <h5>Take a test drive</h5>
                        </div>
                        <div role=form class=wpcf7 id=wpcf7-f346-o1 lang=en-US dir=ltr>
                            <div class=screen-reader-response></div>
                            <form action=https://solutiondots.com/school-management-system/#wpcf7-f346-o1 method=post class=wpcf7-form novalidate=novalidate>
                                <div style="display: none;">
                                    <input type=hidden name=_wpcf7 value=346>
                                    <input type=hidden name=_wpcf7_version value=4.9>
                                    <input type=hidden name=_wpcf7_locale value=en_US>
                                    <input type=hidden name=_wpcf7_unit_tag value=wpcf7-f346-o1>
                                    <input type=hidden name=_wpcf7_container_post value=0></div>
                                <div class="wpcf7-response-output wpcf7-display-none"></div>
                                <p><span class="wpcf7-form-control-wrap your-email"><input
type=email name=your-email value size=40 class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-control" id=test_email aria-required=true aria-invalid=false placeholder=Email...></span> </label><br>
                                    <input type=submit value=Submit class="wpcf7-form-control wpcf7-submit btn pull-right" id=test_submit></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class=row>
                <div class=managing-tree>
                    <div class="col-md-7 col-sm-6 col-xs-8">
                        <h3 class="align-left">Almaali Education Management is a web and mobile application developed specially to handle all the day to day functionalities of School / College</h3>
                         <br>
                         <p> Almaali Education Management System Modules are as listed below</p>
                    </div>
                    <div class="col-md-5 col-sm-6 col-xs-4"><img src=images/Almaali.PNG title="Solution Dots" alt="School attendance software" width=100% class=tree-img></div>
                </div>
            </div>
            <div class=advence-features style="margin-top: 80px;">
                <div class="col-md-4 col-xs-12">
                    <ul>
                        <li>School Module</li>
                        <li>HR Module</li>
                        <li>Finance Module</li>
                        <li>Teacher Module</li>
                        <li>Transport Module</li>
                        <li>Report Module</li>
                        <li>Student Module</li>
                        <li>Admin Module</li>
                        <li>Student Information</li>
                        <li>Employee Module</li>
                    </ul>
                </div>
                <div class="col-md-4 col-xs-12">
                    <ul>
                        <li>Student Access</li>
                        <li>Parent Access</li>
                        <li>Teacher Access and Management</li>
                        <li>Online Student fee Statement view</li>
                        <li>Online Student Attendance view</li>
                        <li>Online Student Result view</li>
                        <li>Parent Mobile notifications</li>
                        <li>Student Announcements</li>
                        <li>Teachers Time Table</li>
                        <li>Exam Management</li>
                    </ul>
                </div>
                <div class="col-md-4 col-xs-12">
                    <ul>
                        <li>Result Management</li>
                        <li>Transportation Management</li>
                        <li>School Account Management</li>
                        <li>School Inventory Management</li>
                        <li>School assets Management</li>
                        <li>School HR Management</li>
                        <li>Web Based System</li>
                        <li>Highly Reliable</li>
                        <li>User Management
                            <li>User Privileges and Logs Management</li>
                    </ul>
                </div>
            </div>
            <div class=row>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class=hr>
                        <div class=" responsive-img text-center"><img src=images/A1.jpg alt="School software" title=Solutiodots style="height: 200px;"></div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class=hr>
                        <div class=" responsive-img text-center"><img src=images/A2.jpg alt="School administration software" title=Solutiodots></div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class=hr>
                        <div class=" responsive-img text-center"><img src=images/A3.jpg alt="education ERP" title=Solutiodots style="height: 200px;"></div>
                    </div>
                </div>
            </div>
            <div class=row>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <h4>The Benefits of the Almali school ERP are as follows :</h4>
                    <br>
                    <h4>Increases Productivity</h4>
                    <p>SolutionDot are offering a lot of features in TotalSchool Systems that completely changed the style of maThe Almali School management system boosts the productivity of the institute. The reason for the increase in productivity is decreased time to maintain the track records and increased accuracy in organizing the data. Less time leads to keep the institute focused on the productivity of the school..</p>
                    <h4>Student-Teacher Collaboration</h4>
                    <p>Using the cloud based ERP leads to the student-teacher collaboration beyond the classroom. This increases the interaction between the staff and the students. The interaction happens over the application (online) where the teacher is available to answer queries of the students. It also facilitates a friendly atmosphere in the academics.</p>
                    <h4>Saves Natural Resources</h4>
                    <p>Stationary right from the paper is saved in the ERP system. It leads to saving the natural resources and keeps a digital track of the data. Also it does not create a mess of the records to be maintained.</p>
                    <h4>Access From Anywhere</h4>
                    <p>The Almaali School Management software can be accessed from anywhere, anytime. A record of everything can be kept due to its easy accessibility. It also facilitates providing immediate information.</p>
                    <h4>Increase In Enrollment</h4>
                    <p>Due to the hectic schedule of the organizations and the tough decision making policies, it becomes troublesome to check in with the enrollment of the students. It is thus required to implement proper software so as to reduce the burden from various activities. Almali lets the organization focus on increasing the students’ enrollment by cutting off the manual headache from the process.</p>
                    <h4>Transparency With Parents Increases</h4>
                    <p>The cloud based software, leads to the interaction with the parents as well. Parents can check on their wards from time to time and keep a track of their advances in the academic fields. This leads to the transparency between the parents and the wards.</p>
                    <h4>Reduction In The Cost Of Communication</h4>
                    <p>All the essential data is available on the software and hence there is a reduction in the cost of communication, which includes calling and sending out messages to let the parents and student know about the various activities within the institution.</p>
                    <h4>Reduces Workload</h4>
                    <p>The workload upon the staff members is reduced as the teachers need to be technology driven. This leads them to work upon the ERP and send out the required data to the students and their parents over the system. It reduces the workload from the teachers and saves time.</p>
                   
                </div>
            </div>
            <div class=row>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class=infrastructure>
                        <div class="col-md-9 col-sm-9 col-xs-12">
                            <div class=hr>
                                <h4>Most Trusted Cloud Infrastructure</h4>
                            </div>
                            <h6>CloudSuite of SolutionDot has combined the industrial expertise that distinguished user’s experience with world’s most trusted infrastructure from Amazon Web Services. Now grow your business by getting the advantage of Amazon’s
                                expertise.</h6>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12">
                            <div class=pull-right><img class="pull-right margin-1x margin-top-50" src=images/amazon-logo.png title="Solution Dots" alt=amazon-logo></div>
                        </div>
                        <div class=clearfix></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        .partner-logo {
            margin: 15px 0px;
        }

        .partner-logo ul li {
            list-style: none;
            display: inline;
            float: left;
            width: 16%;
            margin: 0px 4% 0px 0%;
        }

        .partner-logo p {
            color: #333;
            font-size: 1em;
            text-align: left;
        }

        .country-change {
            position: absolute;
            right: 0;
            bottom: -276px;
        }

        .country-links {
            color: #007ac9;
        }
    </style>
    <div class=partner-logo>
        <div class=container>
            <p>Partners</p>
            <ul>
                <li><img src=images/partner-logos/ibm.png class=img-responsive></li>
                <li><img src=images/partner-logos/google.png class=img-responsive></li>
                <li><img src=images/partner-logos/amazon.png class=img-responsive></li>
                <li><img src=images/partner-logos/honeywell.png class=img-responsive></li>
                <li><img src=images/partner-logos/sap.png class=img-responsive></li>
            </ul>
        </div>
    </div>
  
   
    <?php include("footer.php"); ?>
 <!-- jQuery --> 
<script type="text/javascript" src="js/jquery.js"></script>
<!-- COMPRESSED -->
<script type="text/javascript" src="js/compressed.js"></script>
<!-- Parallax & Animations -->
<script type="text/javascript" src="js/animations.js"></script>
<!-- FUNCTIONS -->
<script type="text/javascript" src="js/functions.js"></script>
<!-- Including all compiled Bootstrap plugins  --> 
<script type="text/javascript" src="dist/js/bootstrap.min.js"></script>
</body>


</html>