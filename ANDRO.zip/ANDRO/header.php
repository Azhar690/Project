
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<title>Androomeda</title>

</head>
<body class="hidenav removebullets">

<!-- Navigation -->
<div class="navigation ">


		<div class="container">
			<div class="logo"><a href="index.html"><img src="images/logo.png" class="white mt5 relative z100" alt=""/></a></div>

			<div class="navbar navbar-default" role="navigation">
				<div class="container-fluid relative">

					<button type="button" class="btn left hide-show-button none">
					    <span class="burgerbar"></span>
					    <span class="burgerbar"></span>
					    <span class="burgerbar"></span>
					</button>
					<a href="#" class="closemenu"></a> 

					<!-- mobile version drop menu -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle hamburger" data-toggle="collapse" data-target=".navbar-collapse">
						  <span class="sr-only">Toggle navigation</span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						</button>
					</div>
					
					<!-- menu -->
					<div class="mainmenu mobanim dark-menu navbar-collapse white collapse offset-0 ">
						<ul class="nav navbar-nav mobpad">

							<li class="dropdown">
							  <a class="dropdown-toggle" href="index1.php">Company</a>
							  <ul class="dropdown-menu">
							  
							  	<li><a href="#">About</a></li>
								<li><a href="#">History</a></li>
								<li><a href="#">Vision</a></li>
								<li><a href="#">Mission</a></li>
								<li><a href="#">Quality Management</a></li>
							  </ul>
							</li>
					        
					        <li class="dropdown">
							  <a class="dropdown-toggle" href="#">Products</a>
							  <ul class="dropdown-menu">
							  

							  	<li class="dropdown relative">
							  		<a class="dropdown-toggle" href="AndroHealthSolutions.php">AndroHealth Solutions</a>
							  		
							  	</li>
							  	<li class="dropdown relative">
							  		<a class="dropdown-toggle" href="Almaali.php">Almaali</a>
							  		
							  	</li>
							  	<li class="dropdown relative">
							  		<a class="dropdown-toggle" href="BinQasem.php">BinQasem</a>
							  		
							  	</li>
							  	<li class="dropdown relative">
							  		<a class="dropdown-toggle" href="#">Alamakin</a>
							  		
							  	</li>

							  	
		
							
								
							  </ul>
							</li>			

							<li class="dropdown">
							  <a class="dropdown-toggle" href="index.html">Industry</a>
							<ul class="dropdown-menu">
							  
							  	<li><a href="#">Health Care</a></li>
								<li><a href="#">Hospitality</a></li>
								
							  </ul>
							</li>
							 
							
							<li class="dropdown">
							  <a class="dropdown-toggle" href="#">Services <b class="caret"></b></a>
							 <ul class="dropdown-menu">
							  

							  	<li class="dropdown relative">
							  		<a class="dropdown-toggle" href="#">IT Services</a>
							  		<ul class="dropdown-menu">
							  			<li><a href="#">Enterprise Softwere Development </a></li>
							  			<li><a href="#">Web Development</a></li>
							  			<li><a href="#">Custom Software Development</a></li>
							  			<li><a href="#">Web/Cloud Based Application</a></li>
							  			
							  		</ul>
							  	</li>
							  	<li class="dropdown relative">
							  		<a class="dropdown-toggle" href="#">Support Services</a>
							  		<ul class="dropdown-menu">
							  			<li><a href="#">Full Installation</a></li>
							  			<li><a href="#">Maintanence Support</a></li>
							  			
							  			
							  		</ul>	
							  	</li>
							  
								
							  </ul>
							</li>
							<li class="dropdown">
							  <a class="dropdown-toggle" href="#">Portfolio <b class="caret"></b></a>
							  
							</li>
							<li class="dropdown">
							  <a class="dropdown-toggle" href="blog.php">Blogs <b class="caret"></b></a>
							
							</li>
							<li class="dropdown">
							  <a class="dropdown-toggle" href="aboutus.php">About Us <b class="caret"></b></a>
							
							</li>
							<li><a href="contact.php">Contact</a></li>
						</ul>
					</div>
				
					

					<div class="dots">
						<a href="#" class="opendots">
							<span class="icon-dots"></span>
							<span class="icon-dots"></span>
							<span class="icon-dots"></span>
						</a>
					</div>			
					
				</div>
			</div>		
			</div>
		</div>

<!-- End of Navigation -->			


<!-- START REVOLUTION SLIDER 3.1 rev5 fullwidth mode -->
<div id="parallax-off" class="tp-banner-container relative">
	<div class="tp-banner" >
		<ul>

			<!-- SLIDE 1  -->
			<li  data-transition="fade" data-slotamount="1" data-masterspeed="2000" data-thumb="images/slider/girls.jpg" data-delay="12000"  data-saveperformance="on"  data-title="Ken Burns Slide" data-color="white">
				<!-- MAIN IMAGE -->
				<img src="images/dummy.png" alt="" data-lazyload="images/Mainimage.jpg" data-bgposition="left center" data-kenburns="on" data-duration="12000" data-ease="Power0.easeInOut" data-bgfit="100" data-bgfitend="100" data-bgpositionend="center center">

				<!-- LAYER 1 -->
				<div class="prlx-on tp-caption slidertitle customin customout tp-resizeme"
					data-x="center"  data-voffset="-50"
					data-y="center"  data-hoffset="0"
											
					data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
					data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
					data-speed="500"
					data-start="3500"
					data-easing="Power3.easeInOut"
					data-splitin="chars"
					data-splitout="chars"
					data-elementdelay="0.05"
					data-endelementdelay="0.05"
					data-endspeed="300"
					style="z-index: 10;"
					>Make The Shift From Now to Next.

				</div>
				
				<!-- LAYER 2 -->
				<div class="prlx-on tp-caption slidersubtitle randomrotate customout tp-resizeme"
					data-x="center"  data-voffset="0"		
					data-y="center"  data-hoffset="0"	
					
					data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
					data-speed="500"
					data-start="500"
					data-easing="Power3.easeInOut"
					data-splitin="chars"
					data-splitout="chars"
					data-elementdelay="0.05"
					data-endelementdelay="0.05"						
					data-endspeed="100"
					style="z-index: 10;"
					>We merge imagination and technology to help brands grow in an age of digital transformation.

				</div>
				
				
				<!-- SCROLL -->
				<div class="prlx-off tp-caption caption-white-bold-caps customin customout"
					data-x="center"   data-voffset="-20"
					data-y="bottom"   data-hoffset="0"	
											
					data-customin="opacity:0;"
					data-customout="opacity:1;"
					data-speed="500"
					data-start="0"
					data-easing="easeOut"  
					style="z-index: 10;"
					>
					<div class=" rs-slideloop" 			
					data-easing="Power3.easeInOut"
					data-speed="0.5"
					data-ys="-5"
					data-ye="5"
					data-xs="0"
					data-xe="0"
					>
					<span class="ti-mouse size30 cwhite"></span>
					</div>
				</div>	

				<!-- Filter dark -->
				<div class="tp-caption customin customout"
					 data-x="center"
					 data-y="center"

					 data-customin="opacity:0;"
					 data-customout="opacity:1;"
					 data-speed="600"
					 data-start="0"
					 data-easing="easeOut"  
					 style="z-index: 4; display:block; background:rgba(0,0,0,0.5); width:100%; height:100%;"
				></div>
			</li>

			<!-- VIDEO  -->
			<li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-color="white">
			
				<!-- MAIN IMAGE -->
				<img src="http://titanicthemes.com/demo/avision/preview/images/slider/video/flexboxvideo.jpg"  alt="video_forest"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">
				<!-- LAYERS -->

				<!-- LAYER NR. 1 -->
				<div class="tp-caption tp-fade fadeout fullscreenvideo"
					data-x="0"
					data-y="0"
					data-speed="1000"
					data-start="0"
					data-easing="Power4.easeOut"
					data-endspeed="1500"
					data-endeasing="Power4.easeIn"
					data-autoplay="true"
					data-autoplayonlyfirsttime="false"
					data-nextslideatend="true"
					data-forceCover="1"
					data-aspectratio="16:9"
					data-forcerewind="on"
					style="z-index: 2">
				<!-- data-dottedoverlay="twoxtwo" -->

				

				</div>

				<!-- Filter maron -->
				<div class="tp-caption "
					 data-x="center"
					 data-y="center"
					 data-speed="600"
					 data-start="0"
					 data-easing="easeOut"  
					 style="z-index: 4; display:block; background:rgba(102,102,51,0.1); width:100%; height:100%;"
					 ></div>

				<!-- Filter dark -->
				<div class="tp-caption customin customout"
					 data-x="center"
					 data-y="center"

					 data-customin="opacity:0;"
					 data-customout="opacity:1;"
					 data-speed="600"
					 data-start="0"
					 data-easing="easeOut"  
					 style="z-index: 4; display:block; background:rgba(0,0,0,0.5); width:100%; height:100%;"
					 ></div>

				<!-- SCROLL -->
				<div class="prlx-off tp-caption caption-white-bold-caps customin customout"
					data-x="center"   data-voffset="-20"
					data-y="bottom"   data-hoffset="0"	
											
					data-customin="opacity:0;"
					data-customout="opacity:1;"
					data-speed="500"
					data-start="0"
					data-easing="easeOut"  
					style="z-index: 10;"
					>
					<div class=" rs-slideloop" 			
					data-easing="Power3.easeInOut"
					data-speed="0.5"
					data-ys="-5"
					data-ye="5"
					data-xs="0"
					data-xe="0"
					>
					<span class="ti-mouse size30 cwhite"></span>
					</div>
				</div>	

				<!-- LAYER NR. 1 -->
				<div class="prlx-on tp-caption slidertitle customin customout"
					data-x="center"
					data-y="center"
					data-captionhidden="on"


					data-splitin="words"
					data-elementdelay="0.25"
					data-start="200"
					data-speed="600"
					data-easing="Back.easeOut"
					data-customin="x:0;y:-20;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"



					data-frames="{ typ :lines;
								 elementdelay :0.1;
								 start:1650;
								 speed:500;
								 ease:Power3.easeOut;
								 animation:x:0;y:-20;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
								 },
								 { typ :lines;
								 elementdelay :0.1;
								 start:2150;
								 speed:500;
								 ease:Power3.easeOut;
								 animation:x:0;y:-40;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
								 }
								 "

					data-splitout="words"
					data-endelementdelay="0.1"
					data-customout="x:0;y:0;z:0;rotationX:40;rotationY:70;rotationZ:0;scaleX:0.85;scaleY:0.85;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
					data-endspeed="500"
					data-endeasing="Power4.easeIn"

					style="z-index: 4">Another Step towards a Better World 

				</div>

				<div class="prlx-on tp-caption slidersubtitle customin customout"
					data-x="center"   data-hoffset="0"
					data-y="center"   data-voffset="30"

					data-splitin=""
					data-elementdelay=""
					data-start="1600"
					data-speed="600"
					data-easing="Power3.easeOut"
					data-customin="x:0;y:30;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"

					data-frames="{ typ :lines;
								 elementdelay :0.1;
								 start:2150;
								 speed:500;
								 ease:Power3.easeOut;
								 animation:x:0;y:-35;z:0;rotationX:00;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;
								 }
								 "

					data-splitout="lines"
					data-endelementdelay="0.1"
					data-customout="x:-230;y:-20;z:0;rotationX:0;rotationY:0;rotationZ:90;scaleX:0.2;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%"
					data-endspeed="500"

					data-endeasing="Back.easeIn"
					data-captionhidden="on"
					style="z-index: 10">Ideal confluence of expertise & innovations ..

				</div>

				
			</li>

		</ul>
		<div class="tp-bannertimer none"></div>
	</div>
</div>
<!-- END REVOLUTION SLIDER -->



</body>
</html>