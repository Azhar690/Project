<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<title>Androomeda</title>
	<!-- Bootstrap implementation -->
	<link href="dist/css/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	    <![endif]-->
	<!-- GOOGLE FONTS -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css" />
	<!-- FONTELLO -->
	<link href="font/fontello/css/fontello.css" rel="stylesheet" type="text/css" />
	<link href="font/fontello/css/animation.css" rel="stylesheet" type="text/css" />
	<!--if IE 7
	link(rel='stylesheet', href='font/fontello/css/fontello-ie7.css')
	-->
	<!-- ANONYMOUS PRO FONT-->
	<link href="http://fonts.googleapis.com/css?family=Anonymous+Pro:400,700" rel="stylesheet" type="text/css" />
	<!-- DRIPICONS -->
	<link href="font/dripicons/webfont.css" rel="stylesheet" type="text/css" />
	<!-- SIMPLE LINE ICONS -->
	<link href="font/simple-line-icons/simple-line-icons.css" rel="stylesheet" type="text/css" />
	<!-- THEMIFY ICONS -->
	<link href="font/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
	<!-- FONTASTIC ICONS -->
	<link href="font/fontastic/styles.css" rel="stylesheet" type="text/css" />
	<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
	<link href="css/extralayers.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="rs-plugin/css/settings.css" media="screen" rel="stylesheet" type="text/css" />
	<!-- CarouFredSel -->
	<link href="css/caroufredsel.css" rel="stylesheet" type="text/css" />
	<!-- WOW.JS REVEAL ANIMATIONS -->
	<link href="css/animate.css" rel="stylesheet" type="text/css" />
	<!-- PYE CHART -->
	<link href="css/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" />
	<!-- Hover Effect Ideas -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,800,300' rel='stylesheet' type='text/css' />
	<link href="css/HoverEffectIdeas/css/demo.css" rel="stylesheet" type="text/css" />
	<link href="css/HoverEffectIdeas/css/set1.css" rel="stylesheet" type="text/css" />
	<!-- Lightcase ( image popup preview ) -->
	<link href="plugins/lightcase/css/lightcase.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>
<body class="hidenav removebullets">

<!-- start preloader -->
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<!-- end preloader -->
<?php include("header.php"); ?>
<!-- END REVOLUTION SLIDER -->

<!-- SECTION CONTACT -->
<div class="bgwhite">
	<div class="container sspacing-title-button">
		<div class="col-md-4">
			<div class="space30"></div>
			<span class="fontproximabold cdark caps"> Company Details</span>
			<div class="divider mtb20"></div>
			
			<strong class="fontproximabold cdark size18">Avision</strong>
			<p class="cdark">
				4676 Devonshire Drive <br/>
				Ravenna, OH 44266
			</p>
			<div class="divider mtb20"></div>
			<strong class="fontproximabold cdark">Email</strong>
			<p>
				<span class="ti-email mr10"></span>  
				<a href="mailto:hello@avision.com">hello@avision.com</a>
			</p>
			<div class="divider mtb20"></div>
			<strong class="fontproximabold cdark">Customer Support</strong>
			<p>
				<span class="ti-mobile mr10"></span>
				<span class="cdark">0 1800 1800 1234</span>
			</p>


		</div>
		<div class="col-md-8">

				<p class="size30 ml10 mb10 cdark pb20">Send us your feedback</p>
				
				<div class="col-md-6">
					<input type="text" class="form-control formlarge" placeholder="Name">
				</div>
				<div class="col-md-6">
					<input type="text" class="form-control formlarge" placeholder="Email">
				</div>
				<div class="col-md-12">
					<input type="text" class="form-control formlarge mt17" placeholder="Phone">
				</div>
				<div class="col-md-12">
					<textarea class="form-control formstyle mt17" rows="7" placeholder="Message"></textarea>
				</div>
				<div class="clearfix"></div>
				<button type="submit" class="btn btnwhitebig btn-default caps ml10 mt30"><i class="icon-mail"></i> Send Message</button>
				<div class="clearfix"></div>

		</div>
	</div>
</div>
<!-- END OF CONTACT -->
<?php include("footer.php"); ?>
<p id="back-top"><a href="#top"><span class="ti-angle-up"></span></a></p>

<div class="newsletter-ani">
	<div class="circle-obj"></div>
	<div class="circle-obj2"><span class="ti-check"></span></div>
	<div class="circle-obj3 opensans xslim">Subscribed</div>
</div>

<!-- jQuery --> 
<script type="text/javascript" src="js/jquery.js"></script>
<!-- COMPRESSED -->
<script type="text/javascript" src="js/compressed.js"></script>
<!-- Parallax & Animations -->
<script type="text/javascript" src="js/animations.js"></script>
<!-- FUNCTIONS -->
<script type="text/javascript" src="js/functions.js"></script>
<!-- Including all compiled Bootstrap plugins  --> 
<script type="text/javascript" src="dist/js/bootstrap.min.js"></script>

</body>
</html>