<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<title>Androomeda</title>
	<!-- Bootstrap implementation -->
	<link href="dist/css/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	    <![endif]-->
	<!-- GOOGLE FONTS -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css" />
	<!-- FONTELLO -->
	<link href="font/fontello/css/fontello.css" rel="stylesheet" type="text/css" />
	<link href="font/fontello/css/animation.css" rel="stylesheet" type="text/css" />
	<!--if IE 7
	link(rel='stylesheet', href='font/fontello/css/fontello-ie7.css')
	-->
	<!-- ANONYMOUS PRO FONT-->
	<link href="http://fonts.googleapis.com/css?family=Anonymous+Pro:400,700" rel="stylesheet" type="text/css" />
	<!-- DRIPICONS -->
	<link href="font/dripicons/webfont.css" rel="stylesheet" type="text/css" />
	<!-- SIMPLE LINE ICONS -->
	<link href="font/simple-line-icons/simple-line-icons.css" rel="stylesheet" type="text/css" />
	<!-- THEMIFY ICONS -->
	<link href="font/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
	<!-- FONTASTIC ICONS -->
	<link href="font/fontastic/styles.css" rel="stylesheet" type="text/css" />
	<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
	<link href="css/extralayers.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="rs-plugin/css/settings.css" media="screen" rel="stylesheet" type="text/css" />
	<!-- CarouFredSel -->
	<link href="css/caroufredsel.css" rel="stylesheet" type="text/css" />
	<!-- WOW.JS REVEAL ANIMATIONS -->
	<link href="css/animate.css" rel="stylesheet" type="text/css" />
	<!-- PYE CHART -->
	<link href="css/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" />
	<!-- Hover Effect Ideas -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,800,300' rel='stylesheet' type='text/css' />
	<link href="css/HoverEffectIdeas/css/demo.css" rel="stylesheet" type="text/css" />
	<link href="css/HoverEffectIdeas/css/set1.css" rel="stylesheet" type="text/css" />
	<!-- Lightcase ( image popup preview ) -->
	<link href="plugins/lightcase/css/lightcase.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>
<body class="hidenav removebullets">

<!-- start preloader -->
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<!-- end preloader -->
<?php include("header.php"); ?>
<!-- END REVOLUTION SLIDER -->

<div class="bglight relative z100">
	<div class="container offset-0 sspacing">
		<div class="row">
			<div class="col-md-4">
				<div class="bgdark clight p50">
					<span class="ti-microphone pull-left size50 pr20 mt-10"></span>
					<h3 class="fontproxima">Company Overview</h3>
					<p class="mt20">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta, eius facilis id illum blanditiis odio ad iste aperiam a eveniet rerum nulla fuga</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="bgmaincolor cwhite p50">
					<span class="ti-stats-up pull-left size50 pr20 mt-10"></span>
					<h3 class="fontproxima"> Our Goal</h3>
					<p class="mt20">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus, sed, totam dolorum nulla cum velit similique impedit quaerat aliquam repellendus odio</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="bgwhite p50">
					<span class="ti-email pull-left size50 pr20 mt-10"></span>
					<h3 class="fontproxima"> Get in Touch</h3>
					<p class="mt20">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore, inventore, sequi dolore ex aliquid itaque ipsam dicta ullam mollitia officiis? Perspiciatis</p>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
</div>

<!-- SECTION SERVICES -->
<div class="bgwhite relative z100">
	<div class="container sspacing">
		<div class="row">
			<div class="col-md-3">
				<p class="size48 mt-20 titlefont">We race together.</p>
			</div>
			<div class="col-md-1">
			</div>
			<div class="col-md-8">
				<h3 class="size48 titlefont">
					We believe that a company’s culture is the key to its success.
				</h3>
				<p class="mt20">
					At FlexBox, our culture is defined by the passionate, positive people who make up our team. 
					We’re ambitious, but no one runs alone. Our people live and breathe the collaborative professionalism that drives our business forward.<br/><br/>

					Whether you join us in New York, London, Dubai or Hong Kong, you’ll find a high-energy environment that matches a rock-solid work ethic with massive amounts of fun. 
					You will find people you love working with and enjoy spending time with outside the office. 
					Our calendar is full of events with a huge variety of sporting and social activities. Being at AlphaSights is less of a job, more of a way of life.<br/><br/>

					Check out some of the photos from recent events. And stay up to date with what we’re up to on our Facebook page. 
				</p>			
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- END OF SECTION SERVICES -->

<?php include("footer.php"); ?>
<p id="back-top"><a href="#top"><span class="ti-angle-up"></span></a></p>

<div class="newsletter-ani">
	<div class="circle-obj"></div>
	<div class="circle-obj2"><span class="ti-check"></span></div>
	<div class="circle-obj3 opensans xslim">Subscribed</div>
</div>

<!-- jQuery --> 
<script type="text/javascript" src="js/jquery.js"></script>
<!-- COMPRESSED -->
<script type="text/javascript" src="js/compressed.js"></script>
<!-- Parallax & Animations -->
<script type="text/javascript" src="js/animations.js"></script>
<!-- FUNCTIONS -->
<script type="text/javascript" src="js/functions.js"></script>
<!-- Including all compiled Bootstrap plugins  --> 
<script type="text/javascript" src="dist/js/bootstrap.min.js"></script>

</body>
</html>