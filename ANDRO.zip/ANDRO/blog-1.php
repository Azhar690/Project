
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<title>Androomeda</title>
	<!-- Bootstrap implementation -->
	<link href="dist/css/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />

	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css" />
	<!-- FONTELLO -->
	<link href="font/fontello/css/fontello.css" rel="stylesheet" type="text/css" />
	<link href="font/fontello/css/animation.css" rel="stylesheet" type="text/css" />
	<!--if IE 7
	link(rel='stylesheet', href='font/fontello/css/fontello-ie7.css')
	-->
	<!-- ANONYMOUS PRO FONT-->
	<link href="http://fonts.googleapis.com/css?family=Anonymous+Pro:400,700" rel="stylesheet" type="text/css" />
	<!-- DRIPICONS -->
	<link href="font/dripicons/webfont.css" rel="stylesheet" type="text/css" />
	<!-- SIMPLE LINE ICONS -->
	<link href="font/simple-line-icons/simple-line-icons.css" rel="stylesheet" type="text/css" />
	<!-- THEMIFY ICONS -->
	<link href="font/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
	<!-- FONTASTIC ICONS -->
	<link href="font/fontastic/styles.css" rel="stylesheet" type="text/css" />
	<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
	<link href="css/extralayers.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="rs-plugin/css/settings.css" media="screen" rel="stylesheet" type="text/css" />
	<!-- CarouFredSel -->
	<link href="css/caroufredsel.css" rel="stylesheet" type="text/css" />
	<!-- WOW.JS REVEAL ANIMATIONS -->
	<link href="css/animate.css" rel="stylesheet" type="text/css" />
	<!-- PYE CHART -->
	<link href="css/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" />
	<!-- Hover Effect Ideas -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,800,300' rel='stylesheet' type='text/css' />
	<link href="css/HoverEffectIdeas/css/demo.css" rel="stylesheet" type="text/css" />
	<link href="css/HoverEffectIdeas/css/set1.css" rel="stylesheet" type="text/css" />
	<!-- Lightcase ( image popup preview ) -->
	<link href="plugins/lightcase/css/lightcase.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>
<body class="hidenav removebullets">

<!-- start preloader -->
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<!-- end preloader -->
<?php include("header.php"); ?>
<!-- END REVOLUTION SLIDER -->

<div class="bgwhite borderbottom space20 relative z20"></div>

<div class="bgxlight borderbottom relative z20">
	<div class="container ptb40 cdark">
		<h3 class="text-center titlefont size30 c999">Blog</h3>
		<div class="pt10 breadcrumbs">
			<a href="#"><span class="ti-home"></span></a> <i>/</i>
			<a href="#">Blog</a>
		</div>
		<!-- <div class="toparrow"></div> -->
	</div>
</div>

<div class="container pt60">
	
	<div id="sidecontent" class="col-md-9 offset-0 pr40 mb50">
	<!-- CONTENT -->

		<!-- post -->
		<div class="col-md-12">
			<div class="relative">
				<img src="images/blog2.jpg" class="fwi" alt=""/>
				<div class="blogdate">
					<p class="fontproxima size30 caps nospace lh30">25</p>
					<p class="fontproxima size12 caps nospace">may</p>
				</div>
			</div>
			   <div class=row style="margin-top: 15px;">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <h4 style="font-weight: bold;">What are the benefits of using a CCTV system in 2019?</h4>
                    <p><span style="font-weight: bold;">CCTV</span>(closed-circuit television) system allows the use of video cameras to monitor the interior and exterior of a property, transmitting the signal to a monitor or set of monitors.More and more of us are switching on the benefits of CCTV security System.. 
Govt of Saudi Arabia promoted the use of CCTV, saying that cameras should be installed by homeowners and businesses to help detectives solve crimes. For a better result, you should install high quality 
<a href="https://www.androomeda.net/">CCTV Cameras</a> on your premises
The need for residential and business CCTV systems is higher than ever before. With the number of police officers patrolling our streets hitting a record low, total recorded offences are up by 14%, as reported by The independent in 2018.
Aside from the obvious advantage of being able to monitor your premises, here are the benefits of using a  CCTV system in 2019:
.</p>
             <h4 style="font-weight: bold;"> Deter criminal activity</h4>      
             <p>This is the biggest and most recognised benefit for those who choose to add CCTV systems to their property. Outside of being able to monitor your premises, CCTV cameras are an excellent deterrent for burglars.Just like seeing a mounted alarm system, an intruder seeing cameras may decide that it’s easier and safer to move elsewhere. It’s much better to prevent intrusion than dealing with it after it’s occurred.</p><span style="font-weight: bold;"><br>“Most criminals are pretty disorganised, they don’t think about it. The reason the cameras are high is two-fold. One is to keep it out of harm’s way.”</span>

              <h4 style="font-weight: bold;">Improved home insurance rates</h4>
              <p>By deterring criminal activity, CCTV security systems reduce your home and property insurance costs. You are less of a target, so the risk is lowered, which means the price of your insurance decreases too.<span style="font-weight: bold;"><br>“If you’re the victim of burglary and your home isn’t properly secured, you may find that your home insurance provider could question your claim and refuse to reimburse you for any loss.”</span></p>

              <h4 style="font-weight: bold;"> Peace of mind</h4>
              <p>A camera system provides people with an increased sense of security and reassurance, particularly in areas where the crime rate is high.Many of the more sophisticated models are wireless, meaning they can be viewed and monitored from your smartphone or tablet.<span style="font-weight: bold;"><br>“As importantly, you get a whole shot of what happened at the event: What did they steal? Did they use a knife? You get all that. But more relevant today is a face. That’s what we need.”</span></p>

              <h4 style="font-weight: bold;">Cost-effective</h4>
              <p>A CCTV system is a cost-effective form of security. Once the system has been installed they are very easy to maintain and require little reparations.Ensure that your cameras are cleaned in order to receive the best performance from your system. Other than this, CCTV systems will keep your premises secure for years.</p>

              <h4 style="font-weight: bold;">Are you worried about your property security?</h4>
              <p>Protecting your home or business isn’t as complicated or expensive as you may think. Modern security systems aren’t just for massive corporations.A modest initial outlay will buy a set up tailored to your requirements, help to protect people, and prevent costly theft or damage.<br>If you would like to benefit from a CCTV system, get in touch today by contacting us. ( Please insert the link of contact us form here )
</span>
</p>


                </div>
            </div>
		</div>

	

	<!-- END CONTENT -->
	</div>
	<div class="col-md-3 offset-0">
		<div id="make-this-fixed-off" class="rightmenu ">
			<ul>
				<li class="title">Categories</li>
				<li><a href="#">Company<span></span></a></li>
				<li><a href="#">Products<span></span></a></li>
				<li><a href="#">Industory<span></span></a></li>
				<li><a href="#">Services<span></span></a></li>
				<li><a href="#">Portfolio<span></span></a></li>
				<li><a href="#">Blogs<span></span></a></li>
				<li><a href="#">AbouUs<span></span></a></li>
				<li><a href="#">Contact<span></span></a></li>
				
			</ul>
			
				<!-- Tabs -->
			<div class="bs-example-tabs mt30">
			    <ul role="tablist" class="nav nav-tabs fb-tabs2" id="myTab2">
			      <li class="active caps fontproximabold"><a data-toggle="tab" role="tab" href="#tab-b">Popular</a></li>
			      <li class="caps fontproximabold"><a data-toggle="tab" role="tab" href="#tab2-b">Latest</a></li>
			    </ul>
			    <div class="tab-content " id="myTabContent2">
			      <div id="tab-b" class="tab-pane fade active in">
			        <div class="mt20">
			        	<div class="sidethumb">
			        		<a href="#"><img src="images/blog2.jpg" class="fwi" alt=""></a>
			        	</div>
			        	<a href="#">What are the benefits of using a CCTV system in 2019?</a>
			        	<p>18 comments</p>
			        	<div class="clearfix mtb10"></div>

			        	<div class="sidethumb">
			        		<a href="#"><img src="images/blog1.jpg" class="fwi" alt=""></a>
			        	</div>
			        	<a href="#">What are the bene6 Reasons why</a>
			        	<p>9 comments</p>
			        	<div class="clearfix mtb10"></div>

			        </div>
			      </div>
			     
			    </div>
			</div>
			<div class="clearfix"></div>
			<!-- Tags -->

			<div class="tags mt50">
				<h1 class="active caps fontproximabold size14">Tags</h1>
				<div class="divider bglight3 mtb10"></div>
				<span>Company</span>
				<span>Products</span>
				<span>Industory</span>
				<span>Services</span>
				<span>Portfolio</span>
				<span>Blogs</span>
				<span>Retina</span>
				<span>AboutUs</span>
				<span>Contact</span>
				
			</div>


		</div>
	</div>
</div>

<?php include("footer.php"); ?>
<p id="back-top"><a href="#top"><span class="ti-angle-up"></span></a></p>

<div class="newsletter-ani">
	<div class="circle-obj"></div>
	<div class="circle-obj2"><span class="ti-check"></span></div>
	<div class="circle-obj3 opensans xslim">Subscribed</div>
</div>

<!-- jQuery --> 
<script type="text/javascript" src="js/jquery.js"></script>
<!-- COMPRESSED -->
<script type="text/javascript" src="js/compressed.js"></script>
<!-- Parallax & Animations -->
<script type="text/javascript" src="js/animations.js"></script>
<!-- FUNCTIONS -->
<script type="text/javascript" src="js/functions.js"></script>
<!-- Including all compiled Bootstrap plugins  --> 
<script type="text/javascript" src="dist/js/bootstrap.min.js"></script>

</body>
</html>