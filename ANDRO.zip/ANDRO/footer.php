<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<title>Androomeda</title>
	
</head>
<body>
<!-- FOOTER -->
<div class="footer">
	<div class="container ptb50 cwhite">
		<div class="row">
			<div class="col-md-3">
				<h5 class="uppercase bold pb20 cwhite titlefont">Androomeda</h5>
				<p>Androomeda Pvt. Ltd. is a Software Development and Engineering company which is lead by the determined and enthusiastic team to provide the best services to their clients.</p>
			</div>
			<div class="col-md-3">
				<h5 class="uppercase bold pb20 cwhite titlefont">Products</h5>
				<ul>
					<li><a href="#">AndroHealth Solutions</a></li>
					<li><a href="#">Almaali</a></li>
					<li><a href="#">BinQasem</a></li>
					<li><a href="#">Alamakin</a></li>
					<li><a href="#">DVR Systems</a></li>
					<li><a href="#">Solar Panels</a></li>
				</ul>
			</div>
			<div class="col-md-3">
				<h5 class="uppercase bold pb20 cwhite titlefont">Quicklinks</h5>
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Our Services</a></li>
					<li><a href="#">Web Development</a></li>
					<li><a href="#">CCTV installation and Maintenance</a></li>
					<li><a href="#">Contact Us</a></li>
				
				</ul>
			</div>
			<div class="col-md-3">
				<h5 class="uppercase bold pb20 cwhite titlefont">Newsletter</h5>
				<p>Latest News Straight to your inbox</p>
				<input type="email" class="form-control newsletter" placeholder="Enter email">
				<button type="submit" class="btn newsletterbtn"><i class="icon-mail"></i></button>
			</div>
		</div>
	</div>
	
	<div class="clearfix"></div>
	<div class="separator100dark"></div>
	
	<div class="container ptb30 cwhite">
		<a href="#"><img src="images/avision-footer.png" class="w90" alt="avision logo" /></a>
		<div class="socialicons right">
			<ul>
				<li class="blue dgrey"><a href="#"><i class="icon-facebook"></i></a></li>
				<li class="lblue lgrey"><a href="#"><i class="icon-twitter-bird"></i></a></li>
				<li class="orange dgrey"><a href="#"><i class="icon-gplus"></i></a></li>
				<li class="pink lgrey"><a href="#"><i class="icon-dribbble"></i></a></li>
				<li class="red dgrey"><a href="#"><i class="icon-youtube"></i></a></li>
			</ul>
		</div>
	</div>
</div>
<!-- End of Footer -->

</body>
</html>
