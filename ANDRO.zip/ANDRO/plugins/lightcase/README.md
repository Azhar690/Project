lightcase.js
======

The smart and flexible Lightbox Plugin.

Lightcase is a flexible and extendable web application to present various media formats on your website and is based on the jQuery Framework.
All information, documentation and developer guidelines are available on the [official lightcase plugin website](
http://cornel.bopp-art.com/lightcase/).
