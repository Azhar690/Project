
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<title>Androomeda</title>
	<!-- Bootstrap implementation -->
	<link href="dist/css/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	    <![endif]-->
	<!-- GOOGLE FONTS -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css" />
	<!-- FONTELLO -->
	<link href="font/fontello/css/fontello.css" rel="stylesheet" type="text/css" />
	<link href="font/fontello/css/animation.css" rel="stylesheet" type="text/css" />
	<!--if IE 7
	link(rel='stylesheet', href='font/fontello/css/fontello-ie7.css')
	-->
	<!-- ANONYMOUS PRO FONT-->
	<link href="http://fonts.googleapis.com/css?family=Anonymous+Pro:400,700" rel="stylesheet" type="text/css" />
	<!-- DRIPICONS -->
	<link href="font/dripicons/webfont.css" rel="stylesheet" type="text/css" />
	<!-- SIMPLE LINE ICONS -->
	<link href="font/simple-line-icons/simple-line-icons.css" rel="stylesheet" type="text/css" />
	<!-- THEMIFY ICONS -->
	<link href="font/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
	<!-- FONTASTIC ICONS -->
	<link href="font/fontastic/styles.css" rel="stylesheet" type="text/css" />
	<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
	<link href="css/extralayers.css" media="screen" rel="stylesheet" type="text/css" />
	<link href="rs-plugin/css/settings.css" media="screen" rel="stylesheet" type="text/css" />
	<!-- CarouFredSel -->
	<link href="css/caroufredsel.css" rel="stylesheet" type="text/css" />
	<!-- WOW.JS REVEAL ANIMATIONS -->
	<link href="css/animate.css" rel="stylesheet" type="text/css" />
	<!-- PYE CHART -->
	<link href="css/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" />
	<!-- Hover Effect Ideas -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,800,300' rel='stylesheet' type='text/css' />
	<link href="css/HoverEffectIdeas/css/demo.css" rel="stylesheet" type="text/css" />
	<link href="css/HoverEffectIdeas/css/set1.css" rel="stylesheet" type="text/css" />
	<!-- Lightcase ( image popup preview ) -->
	<link href="plugins/lightcase/css/lightcase.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>
<body class="hidenav removebullets">

<!-- start preloader -->
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>
<!-- end preloader -->
<?php include("header.php"); ?>
<!-- END REVOLUTION SLIDER -->
<section>
  <div class="row content-wrapper no-left-right-margin">
    <div class="container no-left-right-padding">
      <div class="col-md-12 col-sm-12 welcome-text-main no-left-right-padding">
      
      		<div class="col-md-3 col-sm-3 no-left-right-padding">

                
                <div class="years-logo"><img src="images/images.jpg" alt="" style="margin: 0;padding: 0;max-width: 100%;display: block;width: 100%;"></div><!--years-logo end-->
                
            </div>
            
            <div class="col-md-9 col-sm-9 welcome-cont-set no-left-right-padding">
            
            	<h1>Greetings from <span>AZINOVA</span></h1>
                <h3>Now we are celebrating <span>20 years</span> of success</h3>
                
                <p>Androomeda tap into the power of digital to develop and provide reliable business applications for industry such as Retail, Health care & Education Services In 20 + years, we grew swiftly to serve more than 130 customers across the Kingdom Of Saudi Arabia.</p>
            
            
            </div><!--welcome-cont-set end-->    

      </div><!--welcome-text-main end--> 
    </div><!-- end--> 
  </div><!--row content-wrapper end--> 
</section><!--welcome-text end-->
<!-- 4 COLS -->
<div class="bgwhite bordertopbottom relative z100">
	<div class="container">
		<ul class="squares">
			<li class="col-md-4 text-center">
				<a href="#">
					<i class="ti-palette size40"></i>
					<h4 class="uppercase titlefont">Dedicated Team</h4>
					<p>A full-time, scaleable team of trusted developers.</p>
				</a>
			</li>
			<li class="col-md-4 text-center">
				<a href="#">
					<i class="icon-params size40"></i>
					<h4 class="uppercase titlefont">Flexible Contract</h4>
					<p>Flexible contracts with simple monthly/hourly billing.</p>
				</a>
			</li>
			<li class="col-md-4 text-center">
				<a href="#">
					<i class="icon-mobile-3 size40"></i>
					<h4 class="uppercase titlefont">Trustworthy</h4>
					<p>We have been successfully delivering projects across the Saudi Arabia for a decade</p>
				</a>
			</li>
			
		</ul>
	</div>
</div>
<!-- End of 4 Cols -->

<!-- 4 COLS -->
<div class="bgwhite bordertopbottom relative z100">
	<div class="container">
		<ul class="squares">
			<li class="col-md-4 text-center">
				<a href="#">
					<i class="ti-camera size40"></i>
					<h4 class="uppercase titlefont">Reliable</h4>
					<p>We have always made sure that the projects are delivered on time, every time	</p>
				</a>
			</li>
			<li class="col-md-4 text-center">
				<a href="#">
					<i class="ti-palette size40"></i>
					<h4 class="uppercase titlefont">Integrity</h4>
					<p>We abide by our core values of quality and have maintained that integrity throughout</p>
				</a>
			</li>
			<li class="col-md-4 text-center">
				<a href="#">
					<i class="icon-params size40"></i>
					<h4 class="uppercase titlefont">Client Priority</h4>
					<p>We have always put the needs of our clients first before anything</p>
				</a>
			</li>
			
		</ul>
	</div>
</div>
<!-- End of 4 Cols -->

<!-- Section tabs and menu -->
<section ID="wallsection" class="hauto">
	<div class="prlx-wallsection"></div>
	<div class="container sspacing-title" >
		<div class="row">
			<h3 class="text-center caps pb30 titlefont cwhite">ANDROOMEDA</h3>	
			<div class="container offset-0">
				<div class="col-md-3">
					<ul class="sidemenu dark">
						<li class="inbox title"><a>Our Expertise</a></li>
						<li class="chart1"><a href="#">IT Product Engineering</a></li>
						<li class="people"><a href="#">Web/Cloud Base Applications</a></li>
						<li class="seo"><a href="#">Enterprise Services</a></li>
						<li class="search"><a href="#">IT Solutions</a></li>
						<li class="device"><a href="#">Security Cameras</a></li>
						<li class="feather"><a href="#">Surveillance Systems</a></li>
						<li class="social"><a href="#">Access Control System</a></li>
					</ul>
				</div>
				<div class="col-md-3 cmt border">
					<div class="grid clearfix">
						<figure class="effect-bubba2 nospace block">
							<img src="images/thumb14.jpg" alt=""/>
							<figcaption>
								<h2 class="raleway size22"><span>Join</span> Us</h2>
								<p>Let's Build something together</p>
								<a href="#">View more</a>
							</figcaption>			
						</figure>
					</div>
					<div class="bgwhite p30">
						<h5 class=" caps bold mb15">Build It Right the First Time</h5>
						<a class="btn btnwhite btn-default mt2 mb5" href="#"><i class="icon-article-alt"></i> Contact Us</a>
					</div>
				</div>
				<div class="col-md-6 cmt">
					<div class="bs-example bs-example-tabs">
					    <ul role="tablist" class="nav nav-tabs fb-tabs" id="myTab">
					      <li class="bglight active"><a data-toggle="tab" role="tab" href="#tab"><i class="icon-globe-3"></i><span>About</span></a></li>
					      <li class="bglight"><a data-toggle="tab" role="tab" href="#tab2"><i class="icon-cog"></i><span>Our Philosophy</span></a></li>
					      <li class="bglight"><a data-toggle="tab" role="tab" href="#tab3"><i class="icon-money"></i><span>What Do We Aim For</span></a></li>
					      <li class="bglight"><a data-toggle="tab" role="tab" href="#tab4"><i class="icon-user"></i><span>Our Goal</span></a></li>
					    </ul>
					    <div class="tab-content bgwhite border" id="myTabContent">
					      <div id="tab" class="tab-pane p30 fade active in">
					        <h4>We are a team of software & electronic engineers. We’re here to keep your business growing.</h4>
					        <p class="mtb20">
								Androomeda was established in 1995 as a small provider of security devices  in the kingdom of Saudi Arabia. In the years to come the company grew and expanded its services to IT solutions and power generation plants. After years of hard work and determination, now we are amongst the top leading firms in development, installation and maintenance of digital devices and web applications.
					        </p>
					        <p class="mtb20">
								We have only one mission, that is to serve our customers with the highly customized IT and digital products.
					        </p>
				        	
				        	<p class="borderbottom pb20"></p>
							<a class="btn btnwhite btn-default mt20 mb10 pull-right" href="#"><i class="icon-article-alt"></i> Read more</a>
							<div class="clearfix"></div>
					      </div>
					      <div id="tab2" class="tab-pane p30 fade">
		        	        <h4>Our Philosophy</h4>
		        	        <p class="mtb20">
		        				Our approach to business and software development is relatively simple – be flexible enough to serve any client, engage deeply to understand their needs, be on the cutting edge of technology to provide the best development possible, and stay in tune with clients during development and beyond. It is this philosophy that has kept Androomeda thriving for over 10 years.
		        	        </p>
		                	
		                	<p class="borderbottom pb20"></p>
		        			<a class="btn btnwhite btn-default mt20 mb10 pull-right" href="#"><i class="icon-article-alt"></i> Read more</a>
		        			<div class="clearfix"></div>
					      </div>
					      <div id="tab3" class="tab-pane p30 fade">
		        	        <h4>What do we aim for</h4>
		        	        <p class="mtb20">
		        				We aim to be a body of innovative, creative and dynamic workforce. We believe that people are the most important assets in information & technology industry. Thus, we recruit skilled engineers, groom them and provide an enriching environment which expedites their overall growth and boost their performance.
		        	        </p>
		           
		                	<p class="borderbottom pb20"></p>
		        			<a class="btn btnwhite btn-default mt20 mb10 pull-right" href="#"><i class="icon-article-alt"></i> Read more</a>
		        			<div class="clearfix"></div>
					      </div>
					      <div id="tab4" class="tab-pane p30 fade">
		        	        <h4>Our Goal</h4>
		        	        <p class="mtb20">
		        				It is our primary goal of delivering an outstanding result that ensures the success of your business.Our vision is to deliver long term commercial benefits, based upon our clients key business requirements. The strategies evolved should be economical, efficient, durable, flexible and allow the organisations to respond rapidly to both market and customer needs.

		        	        </p>
		                	<ul class="cgray lh30">
		                		<li><a href="#"><i class="icon-pencil-neg"></i> You can write us an email here.</a></li>
		                		<li><a href="#"><i class="icon-comment"></i> Chat with one of our support guys</a></li>
		                	</ul>
		                	<p class="borderbottom pb20"></p>
		        			<a class="btn btnwhite btn-default mt20 mb10 pull-right" href="#"><i class="icon-article-alt"></i> Read more</a>
		        			<div class="clearfix"></div>
					      </div>
					    </div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</section>
<!-- End tabs and menu -->
<!-- End tabs and menu -->
<div style="margin-top: 70px;">
<header class="section-header">
          <h3>Products We Offer</h3>
</header>
</div>


<<!-- SECTION SERVICES -->
<div class="" style="margin-top: -80px;">
	<div class="container sspacing">
		<div class="row">
			<ul class="services">
				<li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="fa fa-ambulance" style="font-size:40px;"></i>
						<h4 class="uppercase titlefont mtb10">AndroHealth Solutions</h4>
						Business solution platform that assists health care professionals with managing patient health records, claims, revenue and more.
					</a>
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>
				<li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="fa fa-hotel" style="font-size:40px"></i>
						<h4 class="uppercase titlefont mtb10">BinQasem Online Auction System</h4>
						BinQsem is a leading Saudi-based online auction platform in the Middle East. Founded in 2004 by Androomeda.
					</a>
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>
				<li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="fa fa-university" style="font-size:40px"></i>
						<h4 class="uppercase titlefont mtb10">Alamakin Online Booking System</h4>
					Alamakin is an intelligent online booking system for the people who want to book hall in the Kingdom of Saudi Arabia.
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>
				<li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="icon-user lh50 size50 clightgrey"></i>
						<h4 class="uppercase titlefont mtb10">Almaali School Management System</h4>
						Almaali school management system is specially designed to enhance the collaboration 
					</a>
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>
				<li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="icon-fire lh50 size50 clightgrey"></i>
						<h4 class="uppercase titlefont mtb10">Surveillance Systems</h4>
						Androomeda is one of the oldest suppliers of security devices in the kingdom of Saudi Arabia. Our security products include all types of access control devices
					</a>
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>
				<li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="icon-location-1 lh50 size50 clightgrey"></i>
						<h4 class="uppercase titlefont mtb10">Voip</h4>
						We are the largest suppliers of latest VOIP devices. With us you will find all types of VOIP phones and modems from just one place.
					</a>
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>

                <li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="fa fa-ambulance" style="font-size:40px;"></i>
						<h4 class="uppercase titlefont mtb10">Windmill & Solar Panels</h4>
						We are providing our full services in installation & maintenance of power plants based on wind and solar.
					</a>
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>
				<li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="fa fa-ambulance" style="font-size:40px;"></i>
						<h4 class="uppercase titlefont mtb10">DVR System</h4>
						Our digital video recorder system is considered to be the best in the region. Our expert engineers 
					</a>
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>
				<li class="col-md-4 col-sm-6 col-xs-12 text-center">
					<a>
						<i class="fa fa-ambulance" style="font-size:40px;"></i>
						<h4 class="uppercase titlefont mtb10">Vehicle Tracking Systems</h4>
						As a market leader in vehicle tracking systems with more than 20 years of experience  
					</a>
					 <div class="button-hover3">
                   <button type="button" class="btn btn-info">Read More</button>

                     </div>
				</li>

			</ul>	
		</div>
	</div>
</div>
<!-- END OF SECTION SERVICES -->

<!-- SECTION IMAGE -->
<section class="bg222 c999 relative z100 clearfix">
	<div class="cover1 col-xs-12 col-sm-12 col-md-6 h700" >&nbsp;</div>
	<div class="container cus-pos-abs">
		<div class="clearfix"></div>
		<div class="cover-right-text col-sm-12 col-sm-offset-0 col-md-6 col-md-offset-6 sspacing">
			<h1 class="titlefont cwhite">Why Choose Androomeda?</h1>
			<h3 class="titlefont mt20">
				Here are the reasons you can depend on Business System Solutions to keep you and your business up and running
			</h3>
			<div class="separator100 bg333 mtb30"></div>
			<ul class="aboutteamlist">
				<li>
					<div class="clightgrey circlesmall dark left"><i class="icon-magic"></i></div>
					<div class="ctnr">
						<h4 class="cwhite uppercase mb15">Best in Technology</h4>
						<p>Our applications and digital products are build in latest technologies with regular updation</p>
					</div>
				</li>

				<li>				
					<div class="clightgrey circlesmall dark left"><i class="icon-equalizer"></i></div>
					<div class="ctnr">
						<h4 class="cwhite uppercase mb15">Expert Team</h4>
						<p>With more than a decade of experience, our professional and experienced engineers knows exactly the need of the hour.</p>			
					</div>
				</li>

				<li>				
					<div class="clightgrey circlesmall dark left"><i class="icon-mobile"></i></div>
					<div class="ctnr">
						<h4 class="cwhite uppercase mb15">24/7 Support</h4>		
						<p>Our team of support staff are always ready to help you. You can contact us anytime 24hours a day.
</p>
					</div>
				</li>				
				
				<li>				
					<div class="clightgrey circlesmall dark left"><i class="icon-aperture"></i></div>
					<div class="ctnr">
						<h4 class="cwhite uppercase mb15">Customer Satisfaction</h4>
						<p>We are highly confident in our promise to serve you better. </p>	
					</div>	
				</li>
			</ul>			
		</div>
	</div>
</section>
<!-- END OF SECTION IMAGE -->

<!-- THE TEAM SECTION -->
<div class="teamsection bgwhite relative z100 sspacing-title-button owhidden">
	<div class="container">
		<div class="row">
			<h3 class="text-center caps pb30 titlefont">The team</h3>	
			<div class="col-md-3" data-scroll-reveal="enter left over 1s and move 300px after 0.5s">
				<div class="player offset-0" data-scrollreveal="enter left">
					<h4 class="m15">Alice</h4>
					<div class="teampicture">
						<img src="images/team-1.jpg" class="fwi dajy" alt=""/>
						<div class="teamover"></div>
						<p>Graphic Designer</p>
					</div>
					<div class="socialiconswhite m20">
						<ul>
							<li class="blue"><a href="#"><i class="icon-facebook"></i></a></li>
							<li class="lblue"><a href="#"><i class="icon-twitter-bird"></i></a></li>
							<li class="orange"><a href="#"><i class="icon-gplus"></i></a></li>
						</ul>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<div class="col-md-3" data-scroll-reveal="enter top over 1s and move 50px after 0.5s">
				<div class="player offset-0" data-scrollreveal="enter top">
					<h4 class="m15">Jake</h4>
					<div class="teampicture">
						<img src="images/team-2.jpg" class="fwi dajy" alt=""/>
						<div class="teamover"></div>
						<p>Web Developer</p>
					</div>
					<div class="socialiconswhite m20">
						<ul>
							<li class="blue"><a href="#"><i class="icon-facebook"></i></a></li>
							<li class="lblue"><a href="#"><i class="icon-twitter-bird"></i></a></li>
							<li class="orange"><a href="#"><i class="icon-gplus"></i></a></li>
							<li class="pink"><a href="#"><i class="icon-dribbble"></i></a></li>
							<li class="red"><a href="#"><i class="icon-youtube"></i></a></li>
						</ul>
						<div class="clearfix"></div>
					</div>					
				</div>		
			</div>
			<div class="col-md-3" data-scroll-reveal="enter bottom over 1s and move 50px after 0.5s">
				<div class="player offset-0" data-scrollreveal="enter bottom">
					<h4 class="m15">Kate</h4>
					<div class="teampicture">
						<img src="images/team-3.jpg" class="fwi dajy" alt=""/>
						<div class="teamover"></div>
						<p>Marketing Manager</p>
					</div>
					<div class="socialiconswhite m20">
						<ul>
							<li class="blue"><a href="#"><i class="icon-facebook"></i></a></li>
							<li class="lblue"><a href="#"><i class="icon-twitter-bird"></i></a></li>
						</ul>
						<div class="clearfix"></div>
					</div>					
				</div>		
			</div>	
			<div class="col-md-3" data-scroll-reveal="enter right over 1s and move 300px after 0.5s">
				<div class="player offset-0" data-scrollreveal="enter right">
					<h4 class="m15">Simon</h4>
					<div class="teampicture">
						<img src="images/team-4.jpg" class="fwi dajy" alt=""/>
						<div class="teamover"></div>
						<p>CEO</p>
					</div>
					<div class="socialiconswhite m20">
						<ul>
							<li class="blue"><a href="#"><i class="icon-facebook"></i></a></li>
							<li class="lblue"><a href="#"><i class="icon-twitter-bird"></i></a></li>
							<li class="orange"><a href="#"><i class="icon-gplus"></i></a></li>
							<li class="red"><a href="#"><i class="icon-youtube"></i></a></li>
						</ul>
						<div class="clearfix"></div>
					</div>					
				</div>		
			</div>
			
			<div class="clearfix"></div>
			<div class="separator33" data-scroll-reveal="enter top over 1s and move 30px after 0.5s"></div>
			
			<div class="col-md-12" data-scroll-reveal="enter bottom over 1s and move 30px after 0.5s">
			
				<ul class="aboutteamlist">
					<li>
						<div class="circlesmall left"><i class="icon-globe"></i></div>
						<div class="ctnr">
							<h4 class="uppercase mb15 titlefont">Strategy</h4>
							<p>Our strategy to initiate a project is to Working close with you team and learn about your business.</p>
						</div>
					</li>

					<li>				
						<div class="circlesmall left"><i class="icon-signal"></i></div>
						<div class="ctnr">
							<h4 class="uppercase mb15 titlefont">Project Design:</h4>
							<p>We’ll create prototypes and mockups to shape your ideas and requirements into beautiful designs that solve real problems.</p>			
						</div>
					</li>

					<li>				
						<div class="circlesmall left"><i class="icon-group"></i></div>
						<div class="ctnr">
							<h4 class="uppercase mb15 titlefont">Implementation</h4>		
							<p>Our experts are there to implement and deliver your project smoothly and error free. And in case there may any error arises, our 24/7 support will always be there to help you.</p>
						</div>
					</li>				
					
					<li>				
						<div class="circlesmall left"><i class="icon-beaker"></i></div>
						<div class="ctnr">
							<h4 class="uppercase mb15 titlefont">On Site Support</h4>
							<p>On site support is given to all our CCTV, security devices and energy generation plants projects on an ongoing basis. Our team will always help you to onsite and offsite.</p>	
						</div>	
					</li>
				</ul>
			</div>
		
			
			<div class="clearfix"></div>		
			<p class="text-center caps"><a href="#" class="btn btnwhitehuge btn-default">Join our team</a></p>
		</div>
	</div>
</div>
<!-- END OF TEAM SECTION -->

<!-- SECTION PORTFOLIO CAROUSEL-->
<div class="bg222 relative z100 pt50">
	<div class=" text-center">
		<h3 class="titlefont text-center caps pb20 cwhite">The Work</h3>

		<!-- CarouFredSel 4 -->
		<div class="list_carousel5 responsive">
			<ul id="foo5" class="max4">
				<li class="pfover">
					<a href="images/aa.jpg" data-rel="lightcase:myCollection" class="circlebig2"><i class="icon-article-alt"></i></a>
					<a href="images/carousel5/thumb5.jpg" data-rel="lightcase:myCollection2"><img src="images/aa.jpg" class="wdhover" alt=""/></a>
					<div class="caption">
						<p class="title">Add Caption Title</p>
						Your caption description goes here...
					</div>
				</li>
				<li class="pfover">
					<a href="images/aaa.jpg" data-rel="lightcase:myCollection" class="circlebig2"><i class="icon-article-alt"></i></a>
					<a href="images/aaa.jpg" data-rel="lightcase:myCollection2"><img src="images/aaa.jpg" class="wdhover" alt=""/></a>
					<div class="caption">
						<p class="title">Add Caption Title</p>
						Your caption description goes here...
					</div>					
				</li>
				<li class="pfover">
					<a href="images/aaaa.jpg" data-rel="lightcase:myCollection" class="circlebig2"><i class="icon-article-alt"></i></a>
					<a href="images/aaaa.jpg" data-rel="lightcase:myCollection2"><img src="images/aaaa.jpg" class="wdhover" alt=""/></a>
					<div class="caption">
						<p class="title">Add Caption Title</p>
						Your caption description goes here...
					</div>					
				</li>
				<li class="pfover">
					<a href="images/aaaaa-2.jpg" data-rel="lightcase:myCollection" class="circlebig2"><i class="icon-article-alt"></i></a>
					<a href="images/aaaaa-2.jpg" data-rel="lightcase:myCollection2"><img src="images/aaaaa-2.jpg" class="wdhover" alt=""/></a>
					<div class="caption">
						<p class="title">Add Caption Title</p>
						Your caption description goes here...
					</div>					
				</li>	
				<li class="pfover">
					<a href="images/a.webp" data-rel="lightcase:myCollection" class="circlebig2"><i class="icon-article-alt"></i></a>
					<a href="images/a.webp.jpg" data-rel="lightcase:myCollection2"><img src="images/a.webp.jpg" class="wdhover" alt=""/></a>
					<div class="caption">
						<p class="title">Add Caption Title</p>
						Your caption description goes here...
					</div>					
				</li>								
			</ul>
			<div class="clearfix"></div>
			
			<a id="prev5" href="" class="">&#60;</a>
			<a id="next5" href="" class="">&#62;</a>
		</div>
		<!-- End of CarouFredSel 4 -->
		
	</div>
</div>
<!-- END OF SECTION PORTFOLIO CAROUSEL -->

<!-- 2 COLUMNS -->
<div class="bg222 c999 relative z100">
	<div class="container">
		<div class="col-md-6 ptb50">
			<i class="icon-fire size60 pull-left"></i>
			<h4 class="titlefont caps mb10 cwhite">Hot Topics</h4>
			<p>Coupled with top-notch engineering, our approach is the key to our success.News Follow us on
Facebook, twitter, Instagram, linkedIn
</p>			
		</div>
		<div class="h200 col-md-6 cborder ptb50">
			<i class="icon-doc size60 pull-left"></i>
			
			<div class="ml100">
				<h4 class="titlefont caps mb10 cwhite">News</h4>
				<!-- TESTIMONIALS CAROUSEL -->
				<div class="testimonials responsive">
					<ul id="testimonials">
						<li>
							What is the best brand of CCTV system in the kingdom of Saudi Arabia?

						</li>
						<li>Reasons why Andro Health Solutions is the best choice for your hospital?</li>
						<li>Top 10 advantages of using school ERP software </li>
					</ul>
					<div class="clearfix"></div>
					
					
					<!-- <div class="test-timer"></div> -->
					<!-- <div class="w60 ml70">
						<a id="test-prev" href="" class="">&#60;</a>
						<a id="test-next" href="" class="">&#62;</a> 
					</div> -->
					
					<div class="test-pager dark2 ml-10"></div>
				</div>
				<!-- TESTIMONIALS END -->
			</div>
		</div>
	</div>
</div>
<!-- END OF 2 COLUMNS -->

<!-- SECTION -->
<div class="">
	<div class="container sspacing">
		<div class="row">

			<div class="col-md-6">
				<h3 class="caps size40 pb20 titlefont">What makes Androomeda, the partner of choice for enterprises in the digital age?!</h3>
				<!-- Accordion -->
				<div class="panel-group" id="accordion">
				  
				  <div class="panel panel-default">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
						  What We are Offering You?

						</a>
					  </h4>
					  <span></span>
					</div>
					<div id="collapseOne" class="panel-collapse collapse in">
					  <div class="panel-body"><span></span>
					We strive to integrate tech-centred solutions into everyday life and make this planet a better place to live in!
Our team of professionals has years’ long experience and expertise to bring life to your brand and product line. Our services are highly customized around users’ preferences and experiences.


					  </div>
					</div>					
				  </div>
				  
				  <div class="panel panel-default">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
						  Quality Services with Value Addition
						</a>
					  </h4>
					  <span></span>
					</div>
					<div id="collapseTwo" class="panel-collapse collapse">
					  <div class="panel-body"><span></span>
						Stringent quality checks to weed out bugs, technical knots, operational roadblocks and smoothen customer journey.Our value-added business services and solutions, add a string to your portfolio of services to enhance user satisfaction. 

					  </div>
					</div>					
				  </div>

				  
				  <div class="panel panel-default">
					<div class="panel-heading">
					  <h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
						 Timely Deliveries, Secured & Economical

						</a>
					  </h4>
					  <span></span>
					</div>
					<div id="collapseThree" class="panel-collapse collapse">
					  <div class="panel-body"><span></span>
						A one-stop technology solutions centre where time is honored- We deliver in time everytime.Being at the top, Our technology solutions are highly secured to ensure confidentiality and economy to clients.

					  </div>
					</div>					
				  </div>
 				</div>
				<!-- End of Accordion -->			
			</div>
			
			<div class="col-md-6">
				<!-- CarouFredSel 3 -->
				<div class="list_carousel3 responsive">
					<ul id="foo3">
						<li><img src="images/device.png" class="fwi" alt=""/></li>
						<li><img src="images/device-b.png" class="fwi" alt=""/></li>
						<li><img src="images/device-c.png" class="fwi" alt=""/></li>
					</ul>
					<div class="clearfix"></div>
					
					<div class="timer3 none"></div>
					<a id="prev3" href="" class="none">&#60;</a>
					<a id="next3" href="" class="none">&#62;</a>
					<div class="pager3"></div>
				</div>
				<!-- End of CarouFredSel 3 -->
			</div>

			<div class="clearfix"></div>
			<div class="separator33 mt10"></div>

<header class="section-header" style="margin-top: -30px;">
          <h3>Our Industries Expertise
</h3>
</header>

			
			<div class="col-md-3" data-scroll-reveal="enter top over 1s and move 0px after 0.2s" style="margin-top: 50px;">
				<div class="circlesmall left"><i class="icon-child"></i></div>
				<div class="ctnr">
					<h4 class="uppercase mb15 titlefont">Healthcare</h4>
					<p>Support healthcare professionals with innovative solutions to reform the future of the industry.Facility provided from company</p>
				</div>
			</div>
			<div class="col-md-3" data-scroll-reveal="enter top over 1s and move 0px after 0.4s" style="margin-top: 50px;">
				<div class="circlesmall left"><i class="icon-network"></i></div>
				<div class="ctnr">
					<h4 class="uppercase mb15 titlefont">Education Sector</h4>
					<p>Give support and authority to schools, colleges and training centers  administration to handle their tasks</p>
				</div>
			</div>
			<div class="col-md-3" data-scroll-reveal="enter top over 1s and move 0px after 0.6s" style="margin-top: 50px;">
				<div class="circlesmall left"><i class="icon-shield"></i></div>
				<div class="ctnr">
					<h4 class="uppercase mb15 titlefont">Auctions Industry</h4>
					<p>We are trying to be a part of digital shift coming in the auction industry through our complete and dynamic online auction solution.</p>
				</div>
			</div>
			<div class="col-md-3" data-scroll-reveal="enter top over 1s and move 0px after 0.8s" style="margin-top: 50px;">
				<div class="circlesmall left"><i class="icon-ok"></i></div>
				<div class="ctnr">
					<h4 class="uppercase mb15 titlefont">Installation & Innovations of Security Devices</h4>
					<p>Security is the main concern for organizations and individuals.</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End of Facts -->

<!-- FACTS SECTION -->
<section ID="sectionfacts-c" class="hauto">
	<div class="prlx-sectionfacts"></div>
	<div class="container sspacing-title" >
		<div class="row">
			<h3 class="text-center caps pb30 cwhite titlefont">The Facts</h3>	
			
			<div class="col-md-3 text-center" data-scroll-reveal="enter top over 1s and move 30px after 0.2s">
				<div class="factscircle center"><i class="icon-twitter-bird"></i></div>
				<p class="size56 cwhite">250+</p>
				<div class="separatorsmall"></div>			
				<p class="caps cwhite mt20">Successful Projects</p>
			</div>
			<div class="col-md-3 text-center" data-scroll-reveal="enter top over 1s and move 30px after 0.4s">
				<div class="factscircle center"><i class="icon-group-circled"></i></div>
				<p class="size56 cwhite">100+</p>
				<div class="separatorsmall"></div>			
				<p class="caps cwhite mt20">Happy Clients</p>
			</div>
			<div class="col-md-3 text-center" data-scroll-reveal="enter top over 1s and move 30px after 0.6s">
				<div class="factscircle center"><i class="icon-coffee"></i></div>
				<p class="size56 cwhite">97%</p>
				<div class="separatorsmall"></div>			
				<p class="caps cwhite mt20">Percents of users recommend us to friends & family</p>
			</div>
			<div class="col-md-3 text-center" data-scroll-reveal="enter top over 1s and move 30px after 0.8s">
				<div class="factscircle center"><i class="icon-ok-circle"></i></div>
				<p class="size56 cwhite">15+</p>
				<div class="separatorsmall"></div>
				<p class="caps cwhite mt20">Years of Experience</p>
			</div>
		</div>
	</div>
</section>
<!-- End of FACTS SECTION-->

<div class="separator100"></div>

<!-- SECTION CONTACT -->
<div class="">
	<div class="container sspacing-title-button">
		<div class="row">
			<h3 class="text-center caps pb20 titlefont">Contact</h3>
			<p class="text-center size30 mb10 pb20">Since you arrived here, you could leave us a message.</p>
			
			<div class="col-md-3">
				<input type="text" class="form-control formlarge" placeholder="Name">
				<input type="text" class="form-control formlarge mt17" placeholder="Email">
				<input type="text" class="form-control formlarge mt17" placeholder="Phone">
			</div>
			<div class="col-md-9">
				<textarea class="form-control formstyle" rows="7" placeholder="Message"></textarea>
			</div>
			<div class="clearfix"></div>
			<button type="submit" class="btn btnwhitebig btn-default caps center mt30 wow pulse animated" data-wow-delay="0.4s" data-wow-duration="1s" data-wow-iteration="2"><i class="icon-mail"></i> Send Message</button>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!-- END OF CONTACT -->

<div class="separator100"></div>

<!-- SECTION PARTNERS -->
<div class="sspacing-title">
	<div class="container text-center">
		<h3 class="text-center caps titlefont pb10">Partners</h3>

		<!-- CarouFredSel 4 -->
		<div class="list_carousel4 responsive">
			<ul id="foo4">
				<li><img src="images/logos/logo1.jpg" alt=""/></li>
				<li><img src="images/logos/logo2.jpg" alt=""/></li>
				<li><img src="images/logos/logo3.jpg" alt=""/></li>
				<li><img src="images/logos/logo4.jpg" alt=""/></li>
				<li><img src="images/logos/logo5.jpg" alt=""/></li>
				<li><img src="images/logos/logo6.jpg" alt=""/></li>
				<li><img src="images/logos/logo7.jpg" alt=""/></li>
			</ul>
			<div class="clearfix"></div>
			
			<!--
			//This enables more scrolling options and timer
			<div class="timer4"></div>
			<a id="prev4" href="" class="">&#60;</a>
			<a id="next4" href="" class="">&#62;</a>
			<div class="pager4"></div>
			-->
		</div>
		<!-- End of CarouFredSel 4 -->
		
	</div>
</div>
<!-- End of Section -->

<!-- ADDRESS SECTION -->
<section ID="sectionaddress-c" class="">
	<div class="prlx-address"></div>
	<div class="container pt180" >
		
		<div class="col-md-3">
		</div>
		<div class="col-md-9 wow bounceInDown center animated" data-wow-delay="0.3s">
			<h4>Visit our headquarters</h4>
			<h1 class="titlefont size56">Westminster, London</h1>
			<h4>SW1A 0AA, United Kingdom,<br/>
			+44 820 800 1234 </h4>
		</div>
		
	</div>
</section>
<!-- End of Address -->

<?php include("footer.php"); ?>
<p id="back-top"><a href="#top"><span class="ti-angle-up"></span></a></p>

<div class="newsletter-ani">
	<div class="circle-obj"></div>
	<div class="circle-obj2"><span class="ti-check"></span></div>
	<div class="circle-obj3 opensans xslim">Subscribed</div>
</div>

<!-- jQuery --> 
<script type="text/javascript" src="js/jquery.js"></script>
<!-- COMPRESSED -->
<script type="text/javascript" src="js/compressed.js"></script>
<!-- Parallax & Animations -->
<script type="text/javascript" src="js/animations.js"></script>
<!-- FUNCTIONS -->
<script type="text/javascript" src="js/functions.js"></script>
<!-- Including all compiled Bootstrap plugins  --> 
<script type="text/javascript" src="dist/js/bootstrap.min.js"></script>

</body>
</html>